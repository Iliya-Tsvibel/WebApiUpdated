﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightsManagementSystem.DAO.InterfaceDAO
{
    public interface IAdminDAO : IBasicDB<Administrator>
    {
        bool DoesUsernameExist(string userName);
        void ChangePassword(Administrator administrator);
        AirlineCompany GetAirlineById(int id);
        AirlineCompany GetAirlineByUserName(string userName);
        IList<AirlineCompany> GetAllAirlineByCountry(int countryId);
        IList<AirlineCompany> GetAllAirelineCompanies();
        Customer GetCustomerById(int id);
        Customer GetCustomerByUserName(string userName);
        IList<Customer> GetAllCustomerByAddress(string Address);
        IList<Customer> GetAllCustomerByCardNumber(int cardNumber);
        IList<Customer> GetAllCustomers();
        Administrator GetAdminByUserName(string userName);


    }
}

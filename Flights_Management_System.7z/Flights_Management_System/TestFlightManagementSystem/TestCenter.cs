﻿using FlightsManagementSystem;
using FlightsManagementSystem.Facade;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestFlightManagementSystem
{
    static public class TestCenter
    {
       
        static public LoggedInAdministratorFacade defaultFacade = new LoggedInAdministratorFacade();
        static public LoginToken<Administrator> defaultToken = new LoginToken<Administrator> { User = new Administrator { USER_NAME = FlightCenterConfig.ADMIN_USER_NAME, PASSWORD = FlightCenterConfig.ADMIN_PASSWORD } };

        static public string UserTest()
        {
            return "Test " + new Random().Next(100000);
        }
        static public void CleanAllDataBase(out LoginToken<Administrator> token, out LoggedInAdministratorFacade facade)
        {
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("CLEAR_DB", sqlConnection))
                {
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                }

            }
            defaultFacade.CreateNewCountry(defaultToken, new Country() { COUNTRY_NAME = FlightCenterConfig.COUNTRY_NAME, });
            facade = defaultFacade;
            token = defaultToken;
        }

        // Creating and logging as airline company for testing
        static public void CreatingAirlineCompanyAndToken(out LoginToken<AirlineCompany> token, out LoggedInAirlineFacade facade)
        {
            facade = new LoggedInAirlineFacade();
            token = new LoginToken<AirlineCompany> { User = new AirlineCompany { AIRLINE_NAME = FlightCenterConfig.AIRLINE_NAME, USER_NAME = FlightCenterConfig.AIRLINE_USER_NAME, PASSWORD = FlightCenterConfig.AIRLINE_PASSWORD, COUNTRY_CODE = defaultFacade.GetCountryByName(FlightCenterConfig.COUNTRY_NAME).ID } };
            defaultFacade.CreateNewAirline(defaultToken, token.User);
            token.User = defaultFacade.GetAirlineByName(defaultToken, token.User.AIRLINE_NAME);
            
        }
        // Creating and logging as a customer for testing
        static public void CreateAndLogCustomer(out LoginToken<Customer> token, out LoggedInCustomerFacade facade)
        {
            facade = new LoggedInCustomerFacade();
            token = new LoginToken<Customer> { User = new Customer { FIRST_NAME = "Friz", LAST_NAME = "Morgen", USER_NAME = UserTest(), PASSWORD = "1234", ADDRESS = "Berlin", PHONE_NO = "0987", CREDIT_CARD_NUMBER = "12345" } };
            defaultFacade.CreateNewCustomer(defaultToken, token.User);
            token.User = defaultFacade.GetCustomerByUserName(defaultToken, token.User.USER_NAME);
        }
    }
}

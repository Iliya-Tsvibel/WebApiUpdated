﻿using System;
using System.Runtime.Serialization;

namespace FlightsManagementSystem.Facade
{
    [Serializable]
    internal class TicketNotExistExceprion : Exception
    {
        public TicketNotExistExceprion()
        {
        }

        public TicketNotExistExceprion(string message) : base(message)
        {
        }

        public TicketNotExistExceprion(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected TicketNotExistExceprion(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
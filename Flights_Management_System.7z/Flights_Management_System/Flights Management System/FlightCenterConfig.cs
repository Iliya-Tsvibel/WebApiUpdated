﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using FlightsManagementSystem.Facade;

namespace FlightsManagementSystem
{
    public static class FlightCenterConfig
    {
        // For admin functions testing
        public const string ADMIN_NAME = "Iliya";
        public const string ADMIN_LAST_NAME = "Tsvibel";
        public const string ADMIN_USER_NAME = "ADMIN";
        public const string ADMIN_PASSWORD = "1234";
        // For Airline function testing
        public const string AIRLINE_NAME = "AEROFLOT";
        public const string AIRLINE_USER_NAME = "AEROFLOT_21";
        public const string AIRLINE_PASSWORD = "1234";
        public const string COUNTRY_NAME = "Germany";
        // For customer functions testing
        public const string CUSTOMER_NAME = "Yulia";
        public const string CUSTOMER_LAST_NAME = "Tsvibel";
        public const string CUSTOMER_USER_NAME = "Customer";
        public const string CUSTOMER_PASSWORD = "1234";
        // Connection parameters
        public const int TIMEFORTHREADHISTORY = 36000 * 24;
        public static string connectionString = (@"Server = tcp:iliyadb.database.windows.net,1433;Initial Catalog = FlightManagementSystem; Persist Security Info=False;User ID = iliyadb; Password=!Flightsystem; MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout = 30");    /*@"Data Source=.; Initial Catalog=Flights Management System; Integrated Security=True";*/

    } 
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightsManagementSystem.DAO
{
    public interface IFlightDAO : IBasicDB<Flight>
    {
        Dictionary<Flight, int> GetAllFlightsVacancy();
        Flight GetFlightById(long id);
        IList<Flight> GetFlightsByOriginCountry(long countryCode);
        IList<Flight> GetFlightsByDestinationCountry(long countryCode);
        IList<Flight> GetFlightsByDepatrureDate(DateTime departureDate);
        IList<Flight> GetFlightsByLandingDate(DateTime landingDate);
        IList<Flight> GetFlightsByCustomer(Customer customer);
        bool DoesFlightExistByFlightID(long fLIGHT_ID);
        bool CheckInventoryByFlightID(long fLIGHT_ID);
        void UpdateInventoryMinus(long flightId);
        void UpdateInventoryPlus(long flightId);
        Flight GetFlightByAirline(long id);
        Flight GetMinFlightID();
        void RemoveFlightByAirline(Flight flight);
    }
}

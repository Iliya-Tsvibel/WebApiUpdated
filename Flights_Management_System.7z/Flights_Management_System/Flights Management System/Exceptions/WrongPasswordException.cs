﻿using System;
using System.Runtime.Serialization;

namespace TestFlightManagementSystem
{
    [Serializable]
    public class WrongPasswordException : ApplicationException
    {
        public WrongPasswordException()
        {
        }

        public WrongPasswordException(string message) : base(message)
        {
        }

        public WrongPasswordException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected WrongPasswordException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
﻿using System;
using System.Runtime.Serialization;

namespace FlightsManagementSystem.DAO
{
    [Serializable]
    internal class AirlineCompanyAlreadyExistsException : Exception
    {
        public AirlineCompanyAlreadyExistsException()
        {
        }

        public AirlineCompanyAlreadyExistsException(string message) : base(message)
        {
        }

        public AirlineCompanyAlreadyExistsException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected AirlineCompanyAlreadyExistsException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
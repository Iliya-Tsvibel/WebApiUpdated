﻿using System;
using FlightsManagementSystem;
using FlightsManagementSystem.Facade;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestFlightManagementSystem
{
    [TestClass]
    public class TestAnonymousUserFacade
    {
        AnonymousUserFacade anonFacade = new AnonymousUserFacade();

        [TestMethod]
        public void GetAllFlightsTest()
        {
            TestCenter.CleanAllDataBase(out LoginToken<Administrator> adminToken, out LoggedInAdministratorFacade adminFacade);
            TestCenter.CreatingAirlineCompanyAndToken(out LoginToken<AirlineCompany> airlineToken, out LoggedInAirlineFacade airlineFacade);
            Flight flight = new Flight
            {
                AIRLINECOMPANY_ID = airlineFacade.GetAirlineByName(airlineToken, FlightCenterConfig.AIRLINE_NAME).ID,
                ORIGIN_COUNTRY_CODE = airlineFacade.GetCountryByName(airlineToken, FlightCenterConfig.COUNTRY_NAME).ID,
                DESTINATION_COUNTRY_CODE = airlineFacade.GetCountryByName(airlineToken, FlightCenterConfig.COUNTRY_NAME).ID,
                DEPARTURE_TIME = new DateTime(2020, 10, 10, 10, 00, 00),
                LANDING_TIME = new DateTime(2020, 10, 10, 10, 00, 00),
                REMAINING_TICKETS = 250
            };
            Assert.AreEqual(anonFacade.GetAllFlights().Count, 0);
            airlineFacade.CreateFlight(airlineToken, flight);
            Assert.AreEqual(anonFacade.GetAllFlights().Count, 1);

        }

        [TestMethod]
        public void GetAllAirlineCompaniesTest()
        {
            TestCenter.CleanAllDataBase(out LoginToken<Administrator> adminToken, out LoggedInAdministratorFacade adminFacade);
            TestCenter.CreatingAirlineCompanyAndToken(out LoginToken<AirlineCompany> airlineToken, out LoggedInAirlineFacade airlineFacade);
            Assert.AreEqual(anonFacade.GetAllAirlineCompanies().Count, 1);

        }

        [TestMethod]
        public void GetAllVacancyFlightsTest()
        {
            TestCenter.CleanAllDataBase(out LoginToken<Administrator> adminToken, out LoggedInAdministratorFacade adminFacade);
            TestCenter.CreatingAirlineCompanyAndToken(out LoginToken<AirlineCompany> airlineToken, out LoggedInAirlineFacade airlineFacade);
            Flight flight = new Flight
            {
                AIRLINECOMPANY_ID = airlineFacade.GetAirlineByName(airlineToken, FlightCenterConfig.AIRLINE_NAME).ID,
                ORIGIN_COUNTRY_CODE = airlineFacade.GetCountryByName(airlineToken, FlightCenterConfig.COUNTRY_NAME).ID,
                DESTINATION_COUNTRY_CODE = airlineFacade.GetCountryByName(airlineToken, FlightCenterConfig.COUNTRY_NAME).ID,
                DEPARTURE_TIME = new DateTime(2020, 10, 10, 10, 00, 00),
                LANDING_TIME = new DateTime(2020, 10, 10, 10, 00, 00),
                REMAINING_TICKETS = 0
            };
            airlineFacade.CreateFlight(airlineToken, flight);
            Assert.AreEqual(anonFacade.GetAllFlightsVacancy().Count, 0);
        }

      

        // **********************************************************************

        [TestMethod]
        public void GetFlightsByOriginCountryTest()
        {
            TestCenter.CleanAllDataBase(out LoginToken<Administrator> adminToken, out LoggedInAdministratorFacade adminFacade);
            TestCenter.CreatingAirlineCompanyAndToken(out LoginToken<AirlineCompany> airlineToken, out LoggedInAirlineFacade airlineFacade);
            Flight flight = new Flight
            {
                AIRLINECOMPANY_ID = airlineFacade.GetAirlineByName(airlineToken, FlightCenterConfig.AIRLINE_NAME).ID,
                ORIGIN_COUNTRY_CODE = airlineFacade.GetCountryByName(airlineToken, FlightCenterConfig.COUNTRY_NAME).ID,
                DESTINATION_COUNTRY_CODE = airlineFacade.GetCountryByName(airlineToken, FlightCenterConfig.COUNTRY_NAME).ID,
                DEPARTURE_TIME = new DateTime(2020, 10, 10, 10, 00, 00),
                LANDING_TIME = new DateTime(2020, 10, 10, 10, 00, 00),
                REMAINING_TICKETS = 250
            };
            airlineFacade.CreateFlight(airlineToken, flight);
            Assert.AreEqual(anonFacade.GetFlightsByOriginCountry(airlineFacade.GetCountryByName(airlineToken, FlightCenterConfig.COUNTRY_NAME).ID).Count, 1);
        }

        [TestMethod]
        public void GetFlightsByDestinationCountryTest()
        {
            TestCenter.CleanAllDataBase(out LoginToken<Administrator> adminToken, out LoggedInAdministratorFacade adminFacade);
            TestCenter.CreatingAirlineCompanyAndToken(out LoginToken<AirlineCompany> airlineToken, out LoggedInAirlineFacade airlineFacade);
            Flight flight = new Flight
            {
                AIRLINECOMPANY_ID = airlineFacade.GetAirlineByName(airlineToken, FlightCenterConfig.AIRLINE_NAME).ID,
                ORIGIN_COUNTRY_CODE = airlineFacade.GetCountryByName(airlineToken, FlightCenterConfig.COUNTRY_NAME).ID,
                DESTINATION_COUNTRY_CODE = airlineFacade.GetCountryByName(airlineToken, FlightCenterConfig.COUNTRY_NAME).ID,
                DEPARTURE_TIME = new DateTime(2020, 10, 10, 10, 00, 00),
                LANDING_TIME = new DateTime(2020, 10, 10, 10, 00, 00),
                REMAINING_TICKETS = 250
            };
            airlineFacade.CreateFlight(airlineToken, flight);
            Assert.AreEqual(anonFacade.GetFlightsByDestinationCountry(airlineFacade.GetCountryByName(airlineToken, FlightCenterConfig.COUNTRY_NAME).ID).Count, 1);
        }
        [TestMethod]
        public void GetFlightsByDepatrureDateTest()
        {
            TestCenter.CleanAllDataBase(out LoginToken<Administrator> adminToken, out LoggedInAdministratorFacade adminFacade);
            TestCenter.CreatingAirlineCompanyAndToken(out LoginToken<AirlineCompany> airlineToken, out LoggedInAirlineFacade airlineFacade);
            Flight flight = new Flight
            {
                AIRLINECOMPANY_ID = airlineFacade.GetAirlineByName(airlineToken, FlightCenterConfig.AIRLINE_NAME).ID,
                ORIGIN_COUNTRY_CODE = airlineFacade.GetCountryByName(airlineToken, FlightCenterConfig.COUNTRY_NAME).ID,
                DESTINATION_COUNTRY_CODE = airlineFacade.GetCountryByName(airlineToken, FlightCenterConfig.COUNTRY_NAME).ID,
                DEPARTURE_TIME = new DateTime(2020, 10, 10, 10, 00, 00),
                LANDING_TIME = new DateTime(2020, 10, 10, 10, 00, 00),
                REMAINING_TICKETS = 250
            };
            airlineFacade.CreateFlight(airlineToken, flight);
            Assert.AreEqual(anonFacade.GetFlightsByDepatrureDate(new DateTime(2020, 10, 10, 10, 00, 00)).Count, 1);
        }

        //[TestMethod]
        //public void GetFlightsByLandingDateTest()
        //{
        //    TestCenter.CleanAllDataBase(out LoginToken<Administrator> adminToken, out LoggedInAdministratorFacade adminFacade);
        //    TestCenter.CreateAndLogAirlineCompany(out LoginToken<AirlineCompany> airlineToken, out LoggedInAirlineFacade airlineFacade);
        //    Flight flight = new Flight
        //    {
        //        AIRLINECOMPANY_ID = airlineFacade.GetAirlineByName(airlineToken, "Me109").ID,
        //        ORIGIN_COUNTRY_CODE = airlineFacade.GetCountryByName(airlineToken, "Germany").ID,
        //        DESTINATION_COUNTRY_CODE = airlineFacade.GetCountryByName(airlineToken, "Germany").ID,
        //        DEPARTURE_TIME = new DateTime(2020, 10, 10, 10, 00, 00),
        //        LANDING_TIME = new DateTime(2020, 10, 10, 10, 00, 00),
        //        REMAINING_TICKETS = 250
        //    };
        //    airlineFacade.CreateFlight(airlineToken, flight);
        //    Assert.AreEqual(anonFacade.GetFlightsByLandingDate(new DateTime(2020, 10, 10, 10, 00, 00)).Count, 1);
        //}
        //Ask to Itay why date time in DM is differents

    }
}

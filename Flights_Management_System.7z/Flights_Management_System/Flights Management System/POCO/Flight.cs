﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightsManagementSystem
{
   public class Flight : IPoco
    {


        // This is the POCO Class
        public long ID { get; set; }
        public long AIRLINECOMPANY_ID { get; set; }
        public long ORIGIN_COUNTRY_CODE { get; set; }
        public long DESTINATION_COUNTRY_CODE { get; set; }
        public System.DateTime DEPARTURE_TIME { get; set; }
        public System.DateTime LANDING_TIME { get; set; }
        public int REMAINING_TICKETS { get; set; }
        public int Inventory { get; internal set; }

        //**********************************

        public int Vacancy { get; set; }
        //******************************************

        // Constructor without parameters
        public Flight()
        {

        }

        // Constructor with parameters
        public Flight(long iD, long aIRLINECOMPANY_ID, long oRIGIN_COUNTRY_CODE, long dESTINATION_COUNTRY_CODE, DateTime dEPARTURE_TIME, DateTime lANDING_TIME, int rEMAINING_TICKETS)
        {
            ID = iD;
            AIRLINECOMPANY_ID = aIRLINECOMPANY_ID;
            ORIGIN_COUNTRY_CODE = oRIGIN_COUNTRY_CODE;
            DESTINATION_COUNTRY_CODE = dESTINATION_COUNTRY_CODE;
            DEPARTURE_TIME = dEPARTURE_TIME;
            LANDING_TIME = lANDING_TIME;
            REMAINING_TICKETS = rEMAINING_TICKETS;
        }

        // Constructor for test
        public Flight(long aIRLINECOMPANY_ID, long oRIGIN_COUNTRY_CODE, long dESTINATION_COUNTRY_CODE, DateTime dEPARTURE_TIME, DateTime lANDING_TIME, int rEMAINING_TICKETS)
        {
            AIRLINECOMPANY_ID = aIRLINECOMPANY_ID;
            ORIGIN_COUNTRY_CODE = oRIGIN_COUNTRY_CODE;
            DESTINATION_COUNTRY_CODE = dESTINATION_COUNTRY_CODE;
            DEPARTURE_TIME = dEPARTURE_TIME;
            LANDING_TIME = lANDING_TIME;
            REMAINING_TICKETS = rEMAINING_TICKETS;
        }

        //public Flight(long airlineCompanyId, long originCountryCode, long destinationCountryCode,
        //   DateTime departureTime, DateTime landingTime, int remainingTickets)
        //{
        //    this.AIRLINECOMPANY_ID = airlineCompanyId;
        //    this.ORIGIN_COUNTRY_CODE = originCountryCode;
        //    this.DESTINATION_COUNTRY_CODE = destinationCountryCode;
        //    this.DEPARTURE_TIME = departureTime;
        //    this.LANDING_TIME = landingTime;
        //    this.REMAINING_TICKETS = remainingTickets;
        //}

        // Equals check
        // This Function Override The Real Operator == and Check If This ID And Other ID Are Equals
        public static bool operator ==(Flight thisFlight, Flight otherFlight)
        {

            if (ReferenceEquals(thisFlight, null) && ReferenceEquals(otherFlight, null))
                return true;
            if (ReferenceEquals(thisFlight, null) || ReferenceEquals(otherFlight, null))
                return false;

            return (thisFlight.ID == otherFlight.ID);
        }

        // This Function Override The Real Operator != and Check If This ID And Other ID are not Equals
        public static bool operator !=(Flight thisFlight, Flight otherFlight)
        {
            return !(thisFlight == otherFlight);
        }

        // This Function Override The Real Function Equals And Compair Between This ID and Other ID
        public override bool Equals(object obj)
        {
            if (obj == null)
                return false;
            Flight f = obj as Flight;
            if (f == null)
                return false;
            return ID == f.ID;
        }


        //Hash Code override
        public override int GetHashCode()
        {
            return Convert.ToInt32(this.ID);
        }

    }
}

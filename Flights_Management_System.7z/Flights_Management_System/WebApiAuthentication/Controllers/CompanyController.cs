﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http.Description;
using FlightsManagementSystem;
using FlightsManagementSystem.Facade;
using FlightsManagementSystem.Login.InterfaceLogin;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TestFlightManagementSystem;

namespace WebApiAuthentication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Company")]
    public class CompanyController : ControllerBase
    {

        #region Get All Company Tickets
        /// <summary>
        /// GetAllCompanyTickets /tickets/
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [ResponseType(typeof(IList<Ticket>))]
        [Route("tickets/companydetails", Name = "GetTicketsByAirline")]
        [HttpGet]
        public ActionResult<IEnumerable<string>> GetTicketsByAirline(AirlineCompany airline) // may be it can be only by airline name in bady
        {
            BasicAuthenticationController.CreatingAirlineApiTest(); // for testing web api only
            FlyingCenterSystem.TryLogin(FlightCenterConfig.AIRLINE_USER_NAME, FlightCenterConfig.AIRLINE_PASSWORD, out ILoginToken token, out FacadeBase user);
            LoginToken<AirlineCompany> airlineToken = token as LoginToken<AirlineCompany>;
            LoggedInAirlineFacade airlineFacade = user as LoggedInAirlineFacade;
            IList<Ticket> tickets = airlineFacade.GetTicketByAirline(airlineToken, airline);
            if (tickets == null)
            {
                return NotFound();
            }
            return Ok(tickets);
        }
        #endregion

        #region Get All Company Flights
        /// <summary>
        /// GetAllCompanyFlights /flight/airline/{airlineID}
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [ResponseType(typeof(Flight))]
        [Route("flight/airline/{airlineID}", Name = "GetFlightByAirline")]
        [HttpGet]
        public ActionResult<IEnumerable<string>> GetFlightByAirline(long airlineID)
        {
            BasicAuthenticationController.CreatingAirlineApiTest(); // for testing web api only
            FlyingCenterSystem.TryLogin(FlightCenterConfig.AIRLINE_USER_NAME, FlightCenterConfig.AIRLINE_PASSWORD, out ILoginToken token, out FacadeBase user);
            LoginToken<AirlineCompany> airlineToken = token as LoginToken<AirlineCompany>;
            LoggedInAirlineFacade airlineFacade = user as LoggedInAirlineFacade;
            Flight flights = airlineFacade.GetFlightByAirline(airlineToken, airlineID);
            if (flights == null)
            {
                return NotFound();
            }
            return Ok(flights);
        }
        #endregion

        #region Cancel Flight
        /// <summary>
        /// RemoveAirline /flight/cancel/{flightID}
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [ResponseType(typeof(Flight))]
        [Route("flight/cancel/{flightID}", Name = "DeleteFlight")]
        [HttpDelete]
        public ActionResult<IEnumerable<string>> DeleteFlight([FromRoute]long flightID)
        {
            BasicAuthenticationController.CreatingAirlineApiTest(); // for testing web api only
            FlyingCenterSystem.TryLogin(FlightCenterConfig.AIRLINE_USER_NAME, FlightCenterConfig.AIRLINE_PASSWORD, out ILoginToken token, out FacadeBase user);
            LoginToken<AirlineCompany> airlineToken = token as LoginToken<AirlineCompany>;
            LoggedInAirlineFacade airlineFacade = user as LoggedInAirlineFacade;
            Flight flight = airlineFacade.GetFlightById(airlineToken, flightID);
            try
            {
                if (flightID == 0)
                    return BadRequest($"ID flight {flightID} is wrong, please insert correct one");
                else
                    airlineFacade.CancelFlight(airlineToken, flight);
                return Ok(flight);
            }

            catch (Exception exeption)
            {
                return BadRequest(exeption.ToString());
            }
        }
        #endregion

        #region Create New Flight
        /// <summary>
        /// CreateNewAirline /flight/new/
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [ResponseType(typeof(Flight))]
        [Route("flight/new/", Name = "GreateNewFlight")]
        [HttpPost]
        public ActionResult<IEnumerable<string>> GreateNewFlight([FromBody]Flight flight)
        {
            BasicAuthenticationController.CreatingAirlineApiTest(); // for testing web api only
            FlyingCenterSystem.TryLogin(FlightCenterConfig.AIRLINE_USER_NAME, FlightCenterConfig.AIRLINE_PASSWORD, out ILoginToken token, out FacadeBase user);
            LoginToken<AirlineCompany> airlineToken = token as LoginToken<AirlineCompany>;
            LoggedInAirlineFacade airlineFacade = user as LoggedInAirlineFacade;
            try
            {
                if (flight == null)
                {
                    return NotFound();
                }
                airlineFacade.CreateFlight(airlineToken, flight);
                return Ok(flight);
            }

            catch (Exception exeption)
            {
                return BadRequest(exeption.ToString());
            }
        }
        #endregion

        #region Update Flight
        /// <summary>
        /// RemoveAirlineDetails /flight/update/
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [ResponseType(typeof(AirlineCompany))]
        [Route("flight/update/{flghtID}", Name = "UpdateFlightDetails")]
        [HttpPut]
        public ActionResult<IEnumerable<string>> UpdateFlightDetails([FromBody]Flight flight, [FromRoute] long flightID)
        {
            BasicAuthenticationController.CreatingAirlineApiTest(); // for testing web api only
            FlyingCenterSystem.TryLogin(FlightCenterConfig.AIRLINE_USER_NAME, FlightCenterConfig.AIRLINE_PASSWORD, out ILoginToken token, out FacadeBase user);
            LoginToken<AirlineCompany> airlineToken = token as LoginToken<AirlineCompany>;
            LoggedInAirlineFacade airlineFacade = user as LoggedInAirlineFacade;
            try
            {
                if (flight == null)
                {
                    return NotFound();
                }
                else if (flightID == 0)
                    return BadRequest($"Flight ID {flightID} is wrong, please insert correct one");
                else
                    flight.ID = flightID;
                airlineFacade.UpdateFlight(airlineToken, flight);
                return Ok(flight);
            }

            catch (Exception exeption)
            {
                return BadRequest(exeption.ToString());
            }
        }
        #endregion

        #region Update Airline
        /// <summary>
        /// RemoveAirlineDetails /airline/update/
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [ResponseType(typeof(AirlineCompany))]
        [Route("airline/update/{airlineName}", Name = "UpdateAirlineDetailsAsCompanyUser")]
        [HttpPut]
        public ActionResult<IEnumerable<string>> UpdateAirlineDetailsAsCompanyUser([FromBody]AirlineCompany airline, [FromRoute] string airlineName)
        {
            BasicAuthenticationController.CreatingAirlineApiTest(); // for testing web api only
            FlyingCenterSystem.TryLogin(FlightCenterConfig.AIRLINE_USER_NAME, FlightCenterConfig.AIRLINE_PASSWORD, out ILoginToken token, out FacadeBase user);
            LoginToken<AirlineCompany> airlineToken = token as LoginToken<AirlineCompany>;
            LoggedInAirlineFacade airlineFacade = user as LoggedInAirlineFacade;
            try
            {
                if (airline == null)
                {
                    return NotFound();
                }
                else if (airlineName == null)
                    return BadRequest($"Airline name {airlineName} is wrong, please insert correct one");
                else
                    airline.AIRLINE_NAME = airlineName;
                airlineFacade.MofidyAirlineDetails(airlineToken, airline);
                return Ok(airline);
            }

            catch (Exception exeption)
            {
                return BadRequest(exeption.ToString());
            }
        }
        #endregion
    }
}

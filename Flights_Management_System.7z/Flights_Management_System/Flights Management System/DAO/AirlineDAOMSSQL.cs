﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightsManagementSystem.DAO
{
    public class AirlineDAOMSSQL : IAirlineDAO
    {
        public long Add(AirlineCompany t)
        {
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("CREATE_NEW_AIRLINE_COMPANY", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@AIRLINE_NAME", t.AIRLINE_NAME));
                    cmd.Parameters.Add(new SqlParameter("@USER_NAME", t.USER_NAME));
                    cmd.Parameters.Add(new SqlParameter("@PASSWORD", t.PASSWORD));
                    cmd.Parameters.Add(new SqlParameter("@COUNTRY_CODE", t.COUNTRY_CODE));
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                    return t.ID = (long)cmd.ExecuteScalar();
                   
                }
            }
        }
        public AirlineCompany Get(int id)
        {
            AirlineCompany AirlineById = new AirlineCompany();

            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("GET_AIRLINE_BY_ID", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@ID", id));
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            AirlineById.ID = (long)reader["ID"];
                            AirlineById.AIRLINE_NAME = (string)reader["AIRLINE_NAME"];
                            AirlineById.COUNTRY_CODE = (long)reader["COUNTRY_CODE"];
                            AirlineById.USER_NAME = (string)reader["USER_NAME"];
                            AirlineById.PASSWORD = (string)reader["PASSWORD"];
                        }
                    }
                }

            }
            return AirlineById;
        }
        public AirlineCompany GetAirlineByUsername(string name)
        {
            AirlineCompany company = null;
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                SqlCommand FindAirlineByUsername = new SqlCommand("GET_AIRLINE_BY_USER_NAME", sqlConnection);
                FindAirlineByUsername.Parameters.Add(new SqlParameter("@USER_NAME", name));
                FindAirlineByUsername.Connection.Open();
                FindAirlineByUsername.CommandType = CommandType.StoredProcedure;
                sqlConnection.InfoMessage += delegate (object sender, SqlInfoMessageEventArgs e)
                {
                    Console.WriteLine(e.Message);
                };

                SqlDataReader sqlDataReader = FindAirlineByUsername.ExecuteReader(CommandBehavior.Default);

                if (sqlDataReader.Read() == true)
                {
                    company = new AirlineCompany
                    {
                        AIRLINE_NAME = (string)sqlDataReader["AIRLINE_NAME"],
                        PASSWORD = (string)sqlDataReader["PASSWORD"],
                        ID = (long)sqlDataReader["ID"],
                    };
                }

                FindAirlineByUsername.Connection.Close();
            }
            return company;
        }
        public AirlineCompany GetAirlineByName(string name)
        {
            AirlineCompany company = new AirlineCompany();
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                SqlCommand FindAirlineByName = new SqlCommand("GET_AIRLINE_BY_NAME", sqlConnection);
                FindAirlineByName.Parameters.Add(new SqlParameter("@AIRLINE_NAME", name));
                FindAirlineByName.Connection.Open();
                FindAirlineByName.CommandType = CommandType.StoredProcedure;
                sqlConnection.InfoMessage += delegate (object sender, SqlInfoMessageEventArgs e)
                {
                    Console.WriteLine(e.Message);
                };

                SqlDataReader sqlDataReader = FindAirlineByName.ExecuteReader(CommandBehavior.Default);

                while (sqlDataReader.Read() == true)
                {
                    company.USER_NAME = (string)sqlDataReader["USER_NAME"];
                    company.AIRLINE_NAME = (string)sqlDataReader["AIRLINE_NAME"];
                    company.PASSWORD = (string)sqlDataReader["PASSWORD"];
                    company.ID = (long)sqlDataReader["ID"];
                    return company;
                }

                FindAirlineByName.Connection.Close();
            }
            return null;
        }
        public IList<AirlineCompany> GetAll()
        {
            List<AirlineCompany> AllAirlineCompany = new List<AirlineCompany>();

            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT_ALL_AIRLINECOMPANIES", sqlConnection))
                {
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    using (SqlDataReader read = cmd.ExecuteReader())
                    {
                        while (read.Read())
                        {
                            AirlineCompany AirlineCompany = new AirlineCompany();
                            AirlineCompany.ID = (long)read["ID"];
                            AirlineCompany.AIRLINE_NAME = (string)read["AIRLINE_NAME"];
                            AirlineCompany.USER_NAME = (string)read["USER_NAME"];
                            AirlineCompany.PASSWORD = (string)read["PASSWORD"];
                            //AirlineCompany.COUNTRY_CODE = (long)read["COUNTRY_CODE"];
                            AllAirlineCompany.Add(AirlineCompany);
                        }
                    }
                }
            }
            return AllAirlineCompany;
        }
        public IList<AirlineCompany> GetAllAirlinesByCountry(int countryId)
        {
            List<AirlineCompany> AllAirlineByCountry = new List<AirlineCompany>();

            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("GET_AIRLINE_BY_COUNTRY", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@ID", countryId));
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    using (SqlDataReader read = cmd.ExecuteReader())
                    {
                        while (read.Read())
                        {
                            AirlineCompany AirlineCompany = new AirlineCompany();
                            AirlineCompany.ID = (long)read["ID"];
                            AirlineCompany.AIRLINE_NAME = (string)read["AIRLINE_NAME"];
                            AirlineCompany.USER_NAME = (string)read["USER_NAME"];
                            AirlineCompany.PASSWORD = (string)read["PASSWORD"];
                            AirlineCompany.COUNTRY_CODE = (long)read["COUNTRY_CODE"];
                            AllAirlineByCountry.Add(AirlineCompany);
                        }
                    }
                }
            }
            return AllAirlineByCountry;
        }
        public void Remove(AirlineCompany t)
        {
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("REMOVE_AIRLINE_DETAILS", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@AIRLINE_NAME", t.AIRLINE_NAME));
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                }
            }
        }
        public void Update(AirlineCompany t)
        {
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("UPDATE_AIRLINE_DETAILS", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@AIRLINE_NAME", t.AIRLINE_NAME));
                    cmd.Parameters.Add(new SqlParameter("@USER_NAME", t.USER_NAME));
                    cmd.Parameters.Add(new SqlParameter("@PASSWORD", t.PASSWORD));
                    cmd.Parameters.Add(new SqlParameter("@COUNTRY_CODE", t.COUNTRY_CODE));
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                    cmd.Connection.Close();
                }

            }
        }
      
        public bool DoesAirlineExist(string airlineName)
        {
            int result;

            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                SqlCommand FindAirlineByName = new SqlCommand("GET_AIRLINE_BY_NAME", sqlConnection);
                FindAirlineByName.Parameters.Add(new SqlParameter("@AIRLINE_NAME", airlineName));
                FindAirlineByName.Connection.Open();
                FindAirlineByName.CommandType = CommandType.StoredProcedure;
                SqlDataReader sqlDataReader = FindAirlineByName.ExecuteReader(CommandBehavior.Default);

                if (sqlDataReader.Read() == true)
                {
                    result = 1;
                }
                else
                    result = 0;


                FindAirlineByName.Connection.Close();

                if (result == 1)
                {
                    return true;
                }
                else
                    return false;

            }

        }
        public void ChangePassword(AirlineCompany company)
        {
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("CHANGE_AIRLINE_PASSWORD", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@AIRLINE_NAME", company.AIRLINE_NAME));
                    cmd.Parameters.Add(new SqlParameter("@PASSWORD", company.PASSWORD));

                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}

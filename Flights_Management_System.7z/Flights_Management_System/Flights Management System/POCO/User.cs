﻿using Flights_Management_System.POCO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightsManagementSystem.POCO
{
    public class User : IUser, IPoco
    {

        // This is the POCO Class
        public string ID { get; set; }
        public string USER_NAME { get; set; }
        public string PASSWORD { get; set; }
        public Type ROLE { get; set; }
        public UserAccessType TYPE_OF_USER { get; set; }

        // Full constructor
        public User(string iD, string uSER_NAME, string pASSWORD, Type rOLE, UserAccessType tYPE_OF_USER)
        {
            ID = iD;
            USER_NAME = uSER_NAME;
            PASSWORD = pASSWORD;
            ROLE = rOLE;
            TYPE_OF_USER = tYPE_OF_USER;
        }

        // Constructor without ID
        public User(string uSER_NAME, string pASSWORD, Type rOLE, UserAccessType tYPE_OF_USER)
        {
            USER_NAME = uSER_NAME;
            PASSWORD = pASSWORD;
            ROLE = rOLE;
            TYPE_OF_USER = tYPE_OF_USER;
        }

        // Empty constructor
        public User()
        {
            
        }

    }

}
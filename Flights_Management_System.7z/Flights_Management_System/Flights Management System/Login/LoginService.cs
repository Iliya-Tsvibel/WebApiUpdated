﻿using Flights_Management_System.POCO;
using FlightsManagementSystem.DAO;
using FlightsManagementSystem.DAO.InterfaceDAO;
using FlightsManagementSystem.Facade;
using FlightsManagementSystem.Login.InterfaceLogin;
using FlightsManagementSystem.POCO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestFlightManagementSystem;

namespace FlightsManagementSystem
{
    public class LoginService : AnonymousUserFacade, ILoginService
    {

        private IAdminDAO _adminDAO = new AdminDAOMSSQL();
        private IAirlineDAO _airlineDAO = new AirlineDAOMSSQL();
        private ICustomerDAO _customerDAO = new CustomerDAOMSSQL();

        public bool TryCustomerLogin(string userName, string password, out LoginToken<Customer> token)
        {
            token = null;
            Customer customer = _customerDAO.GetCustomerByUserame(userName);
            if (customer != null)
            {
                if (customer.PASSWORD.ToUpper() == password.ToUpper())
                {
                    token = new LoginToken<Customer>() { User = customer };
                    return true;
                }
                else
                    throw new WrongPasswordException("Your Password Isn't Match To Your UserName!");
            }
            return false;

        }
        public bool TryAirlineLogin(string userName, string password, out LoginToken<AirlineCompany> token)
        {
            token = null;
            AirlineCompany airlineCompany = _airlineDAO.GetAirlineByUsername(userName);
            if (airlineCompany != null)
            {
                if (airlineCompany.PASSWORD.ToUpper() == password.ToUpper())
                {
                    token = new LoginToken<AirlineCompany> { User = airlineCompany };
                    return true;
                }
                else
                {
                    throw new WrongPasswordException("Your Password Isn't Match To Your UserName!");
                }
            }
            return false;
        }

        public bool TryAdminLogin(string userName, string password, out LoginToken<Administrator> token)
        {
            token = null;

            if (userName.ToUpper() == FlightCenterConfig.ADMIN_USER_NAME)
            {
                if (password == FlightCenterConfig.ADMIN_PASSWORD)
                {
                    token = new LoginToken<Administrator> { User = new Administrator { ID = 0, USER_NAME = FlightCenterConfig.ADMIN_USER_NAME, PASSWORD = FlightCenterConfig.ADMIN_PASSWORD } };
                    return true;
                }
                else
                {
                    throw new WrongPasswordException("Your Password Isn't Match To Your UserName!");
                }
            }

            Administrator admin = _adminDAO.GetAdminByUserName(userName);
            if (admin != null)
                if (admin.USER_NAME.ToUpper() == userName.ToUpper())
                {
                    if (admin.PASSWORD.ToUpper() == password.ToUpper())
                    {
                        token = new LoginToken<Administrator> { User = admin };
                        return true;
                    }
                    else
                        throw new WrongPasswordException("Your Password Isn't Match To Your UserName!");
                }
            return false;
            throw new UserNotExistException("User not found. Try another username");
        }
    }
}



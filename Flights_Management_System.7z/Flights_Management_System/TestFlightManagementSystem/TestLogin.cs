﻿using System;
using FlightsManagementSystem;
using FlightsManagementSystem.Facade;
using FlightsManagementSystem.Login.InterfaceLogin;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestFlightManagementSystem
{
    [TestClass]
    public class TestLogin
    {
        [TestMethod]
        [ExpectedException(typeof(WrongPasswordException))]
        public void AdminWrongPasswordExceptionTest()
        {
            FlyingCenterSystem.TryLogin(FlightCenterConfig.ADMIN_USER_NAME, "12345", out ILoginToken token, out FacadeBase user);
        }

        [TestMethod]
        public void AdminLoginSuccesfullyTest()
        {
            FlyingCenterSystem.TryLogin(FlightCenterConfig.ADMIN_USER_NAME, FlightCenterConfig.ADMIN_PASSWORD, out ILoginToken token, out FacadeBase user);
            LoginToken<Administrator> newAdminToken = token as LoginToken<Administrator>;
            Assert.AreNotEqual(newAdminToken, null);
        }

        [TestMethod]
        [ExpectedException(typeof(WrongPasswordException))]
        public void AdminDAOWrongPasswordExceptionTest()
        {
            TestCenter.CleanAllDataBase(out LoginToken<Administrator> adminToken, out LoggedInAdministratorFacade adminFacade);
            Administrator newAdmin = new Administrator { FIRST_NAME = "Iliya", LAST_NAME = "Tsvibel", USER_NAME = "Admin" + TestCenter.UserTest(), PASSWORD = "1234" };
            adminFacade.CreateNewAdmin(adminToken, newAdmin);
            FlyingCenterSystem.TryLogin(newAdmin.USER_NAME, "12345", out ILoginToken token, out FacadeBase user);
        }

        [TestMethod]
        public void AdminDAOLoginSuccesfullyTest()
        {
            TestCenter.CleanAllDataBase(out LoginToken<Administrator> adminToken, out LoggedInAdministratorFacade adminFacade);
            Administrator newAdmin = new Administrator { FIRST_NAME = "Iliya", LAST_NAME = "Tsvibel", USER_NAME = "Admin" + TestCenter.UserTest(), PASSWORD = "1234" };
            adminFacade.CreateNewAdmin(adminToken, newAdmin);
            FlyingCenterSystem.TryLogin(newAdmin.USER_NAME, newAdmin.PASSWORD, out ILoginToken token, out FacadeBase user);
            LoginToken<Administrator> newAdminToken = token as LoginToken<Administrator>;
            Assert.AreNotEqual(newAdmin, null);
        }

        [TestMethod]
        [ExpectedException(typeof(WrongPasswordException))]
        public void AirlineWrongPasswordExceptionTest()
        {
            TestCenter.CleanAllDataBase(out LoginToken<Administrator> adminToken, out LoggedInAdministratorFacade adminFacade);
            Country newCountry = new Country { COUNTRY_NAME = FlightCenterConfig.COUNTRY_NAME };
            adminFacade.CreateNewCountry(adminToken, newCountry);
            AirlineCompany newAirline = new AirlineCompany { AIRLINE_NAME = FlightCenterConfig.AIRLINE_NAME, USER_NAME = FlightCenterConfig.AIRLINE_USER_NAME, PASSWORD = FlightCenterConfig.AIRLINE_PASSWORD, COUNTRY_CODE = adminFacade.GetCountryByName(FlightCenterConfig.COUNTRY_NAME).ID };
            adminFacade.CreateNewAirline(adminToken, newAirline);
            FlyingCenterSystem.TryLogin(newAirline.USER_NAME, "12345", out ILoginToken token, out FacadeBase user);
        }

        [TestMethod]
        public void AirlineLoginSuccesfullyTest()
        {
            TestCenter.CleanAllDataBase(out LoginToken<Administrator> adminToken, out LoggedInAdministratorFacade adminFacade);
            AirlineCompany newAirline = new AirlineCompany { AIRLINE_NAME = FlightCenterConfig.AIRLINE_NAME, USER_NAME = FlightCenterConfig.AIRLINE_USER_NAME, PASSWORD = FlightCenterConfig.AIRLINE_PASSWORD, COUNTRY_CODE = adminFacade.GetCountryByName(FlightCenterConfig.COUNTRY_NAME).ID };
            adminFacade.CreateNewAirline(adminToken, newAirline);
            FlyingCenterSystem.TryLogin(newAirline.USER_NAME, FlightCenterConfig.AIRLINE_PASSWORD, out ILoginToken token, out FacadeBase user);
            Assert.AreNotEqual(newAirline, null);
        }

        [TestMethod]
        [ExpectedException(typeof(WrongPasswordException))]
        public void CustomerWrongPasswordExceptionTest()
        {
            TestCenter.CleanAllDataBase(out LoginToken<Administrator> adminToken, out LoggedInAdministratorFacade adminFacade);
            Customer newCustomer = new Customer { FIRST_NAME = "Iliya", LAST_NAME = "Tsvibel", USER_NAME = "Iliya79" + TestCenter.UserTest(), PASSWORD = "1234", ADDRESS = "Rishon Le Zion", PHONE_NO = "0546800559", CREDIT_CARD_NUMBER = "123456" };
            adminFacade.CreateNewCustomer(adminToken, newCustomer);
            FlyingCenterSystem.TryLogin(newCustomer.USER_NAME, "12345", out ILoginToken token2, out FacadeBase user2);
        }
        [TestMethod]
        public void LoginSuccesfullyAsCustomer()
        {
            TestCenter.CleanAllDataBase(out LoginToken<Administrator> adminToken, out LoggedInAdministratorFacade adminFacade);
            Customer newCustomer = new Customer { FIRST_NAME = "Iliya", LAST_NAME = "Tsvibel", USER_NAME = "Iliya79" + TestCenter.UserTest(), PASSWORD = "1234", ADDRESS = "Rishon Le Zion", PHONE_NO = "0546800559", CREDIT_CARD_NUMBER = "123456" };
            adminFacade.CreateNewCustomer(adminToken, newCustomer);
            FlyingCenterSystem.TryLogin(newCustomer.USER_NAME, "1234", out ILoginToken token2, out FacadeBase user2);
            Assert.AreNotEqual(newCustomer, null);
        }
    }
}

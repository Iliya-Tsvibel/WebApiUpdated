﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightsManagementSystem.DAO
{
    public class CountryDAOMSSQL : ICountryDAO
    {
        public long Add(Country t)
        {
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("ADD_NEW_COUNTRY", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@COUNTRY_NAME", t.COUNTRY_NAME));
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                    return t.ID = (long)cmd.ExecuteScalar();
                }

            }
        }

        public Country Get(int id)
        {
            Country CountryById = new Country();

            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("GET_COUNTRY_BY_ID", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@ID", id));
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            CountryById.ID = id;
                            CountryById.COUNTRY_NAME = (string)reader["COUNTRY_NAME"];
                        }
                    }
                    cmd.Connection.Close();
                }

            }
            return CountryById;
        }

        public Country GetByName(string name)
        {
            Country CountryByName = new Country();

            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("GET_COUNTRY_BY_NAME", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@COUNTRY_NAME", name));
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            CountryByName.ID = (long)reader["ID"];
                            CountryByName.COUNTRY_NAME = name;
                            return CountryByName;
                        }
                    }
                    cmd.Connection.Close();
                }

            }
            return null;
        }
        public IList<Country> GetAll()
        {
            List<Country> AllCountries = new List<Country>();

            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT_ALL_COUNTRIES", sqlConnection))
                {
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    using (SqlDataReader read = cmd.ExecuteReader())
                    {
                        while (read.Read())
                        {
                            Country Country = new Country();
                            Country.ID = (int)read["ID"];
                            Country.COUNTRY_NAME = (string)read["COUNTRY_NAME"];
                            AllCountries.Add(Country);
                        }
                    }
                }
            }
            return AllCountries;
        }

        public void Remove(Country t)
        {
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("REMOVE_COUNTRY", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@COUNTRY_CODE", t.COUNTRY_NAME));
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void Update(Country t)
        {
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("UPDATE_COUNTRY_NAME", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@ID", t.ID));
                    cmd.Parameters.Add(new SqlParameter("@COUNTRY_NAME", t.COUNTRY_NAME));
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                }

            }
        }
    }
}

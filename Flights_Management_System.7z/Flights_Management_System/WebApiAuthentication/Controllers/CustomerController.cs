﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http.Description;
using FlightsManagementSystem;
using FlightsManagementSystem.Facade;
using FlightsManagementSystem.Login.InterfaceLogin;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace WebApiAuthentication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Customer")]
    public class CustomerController : ControllerBase
    {

        #region Get All Customer Tickets
        /// <summary>
        /// GetAllCompanyTickets /customer/tickets/{userName}
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [ResponseType(typeof(IList<Ticket>))]
        [Route("customer/tickets/{userName}", Name = "GetTicketsByCustomer")]
        [HttpGet]
        public ActionResult<IEnumerable<string>> GetTicketsByCustomer(Customer customer)
        {
            BasicAuthenticationController.CreatingAirlineApiTest(); // for testing web api only
            FlyingCenterSystem.TryLogin(FlightCenterConfig.CUSTOMER_USER_NAME, FlightCenterConfig.CUSTOMER_PASSWORD, out ILoginToken token, out FacadeBase user);
            LoginToken<Customer> customerToken = token as LoginToken<Customer>;
            LoggedInCustomerFacade customerFacade = user as LoggedInCustomerFacade;
            IList<Ticket> tickets = customerFacade.GetTicketByCustomer(customerToken, customer);
            if (tickets == null)
            {
                return NotFound();
            }
            return Ok(tickets);
        }
        #endregion

        #region Purchase Ticket
        /// <summary>
        /// PurchaseTicket /ticket/new/
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [ResponseType(typeof(Ticket))]
        [Route("ticket/new/", Name = "PurchaseTicket")]
        [HttpPost]
        public ActionResult<IEnumerable<string>> PurchaseTicket([FromBody]Ticket ticket)
        {
            BasicAuthenticationController.CreatingAirlineApiTest(); // for testing web api only
            FlyingCenterSystem.TryLogin(FlightCenterConfig.CUSTOMER_USER_NAME, FlightCenterConfig.CUSTOMER_PASSWORD, out ILoginToken token, out FacadeBase user);
            LoginToken<Customer> customerToken = token as LoginToken<Customer>;
            LoggedInCustomerFacade customerFacade = user as LoggedInCustomerFacade;
            try
            {
                if (ticket == null)
                {
                    return NotFound();
                }
                customerFacade.PurchaseTicket(customerToken, ticket);
                return Ok(ticket);
            }

            catch (Exception exeption)
            {
                return BadRequest(exeption.ToString());
            }
        }
        #endregion

        #region Remove Ticket
        /// <summary>
        /// RemoveTicket /ticket/remove/
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [ResponseType(typeof(Ticket))]
        [Route("ticket/remove/{ticketID}", Name = "DeleteTicket")]
        [HttpDelete]
        public ActionResult<IEnumerable<string>> DeleteTicket([FromRoute]long ticketID)
        {
            BasicAuthenticationController.CreatingAirlineApiTest(); // for testing web api only
            FlyingCenterSystem.TryLogin(FlightCenterConfig.CUSTOMER_USER_NAME, FlightCenterConfig.CUSTOMER_PASSWORD, out ILoginToken token, out FacadeBase user);
            LoginToken<Customer> customerToken = token as LoginToken<Customer>;
            LoggedInCustomerFacade customerFacade = user as LoggedInCustomerFacade;
            Ticket ticket = new Ticket() { ID = ticketID };
            customerFacade.CancelTicket(customerToken, ticket);
            //customerFacade.CancelTicketByCustomer(customerToken.User.ID, ticket);
            return Ok(ticket);

        }
        #endregion
    }
}

﻿using Prism.Commands;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Fly_System_DB_Generator
{
    public class MainWindowViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public ICommand AddToDB { get; set; }
        public ICommand ReplaceDB { get; set; }
        public ICommand CleanDB { get; set; }
        public DBGeneratorClass GenerationProcess { get; set; }
        public class WebResult
        {
            public WebUser[] results;
        }

        public class WebUser
        {
            public string cell;
            public string phone;
            public Name name;
            public Location location;
            public Login login;
        }
        public class Login
        {
            public string username;
            public string password;
        }
        public class Location
        {
            //public string street;
            public string city;
            public string state;
            public string postcode;

        }
        public class Name
        {
            public string first;
            public string last;
        }
        public MainWindowViewModel()
        {
            GenerationProcess = new DBGeneratorClass();

            AddToDB = new DelegateCommand(
                () =>
                {
                    AddDataToDB();
                }
                );

            CleanDB = new DelegateCommand(
                () =>
                {
                    DeleteDB();
                }
                );
        }

        private void AddDataToDB()
        {
            GenerationProcess.GenerateDB();
        }

        private void DeleteDB()
        {
            GenerationProcess.DeleteDB();
        }
    }
}

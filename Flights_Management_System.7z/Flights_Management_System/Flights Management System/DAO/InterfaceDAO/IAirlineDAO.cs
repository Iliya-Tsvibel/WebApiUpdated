﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightsManagementSystem.DAO
{
    public interface IAirlineDAO : IBasicDB<AirlineCompany>
    {

        AirlineCompany GetAirlineByUsername(string name);
        AirlineCompany GetAirlineByName(string name);
        IList<AirlineCompany> GetAllAirlinesByCountry(int countryId);
        bool DoesAirlineExist(string airlineName);
        void ChangePassword(AirlineCompany company);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightsManagementSystem
{
    public class Ticket : IPoco
    {
        // This is the POCO Class
        public long ID { get; set; }
        public long FLIGHT_ID { get; set; }
        public long CUSTOMER_ID { get; set; }

        // Constructor without parameters
        public Ticket()
        {

        }

        // Constructor with parameters
        public Ticket(long iD, long fLIGHT_ID, long cUSTOMER_ID)
        {
            ID = iD;
            FLIGHT_ID = fLIGHT_ID;
            CUSTOMER_ID = cUSTOMER_ID;
        }

        // Constructor for test

        public Ticket(long fLIGHT_ID, long cUSTOMER_ID)
        {
            FLIGHT_ID = fLIGHT_ID;
            CUSTOMER_ID = cUSTOMER_ID;
        }


        // Equals check
        // This Function Override The Real Operator == and Check If This ID And Other ID Are Equals
        public static bool operator ==(Ticket thisTicket, Ticket otherTicket)
        {
            if (ReferenceEquals(thisTicket, null) && ReferenceEquals(otherTicket, null))
                return true;
            if (ReferenceEquals(thisTicket, null) || ReferenceEquals(otherTicket, null))
                return false;
            return (thisTicket.ID == otherTicket.ID);
        }

        // This Function Override The Real Operator != and Check If This ID And Other ID are not Equals
        public static bool operator !=(Ticket thisTicket, Ticket otherTicket)
        {
            return !(thisTicket == otherTicket);
        }

        public override bool Equals(object obj)
        {
            //return Equals(obj as Ticket);
            if (obj == null)
                return false;
            Ticket t = obj as Ticket;
            if (t == null)
                return false;
            return ID == t.ID;
        }

        public bool Equals(Ticket other)
        {
            return other != null &&
                   ID == other.ID;
        }

        //Hash Code override
        public override int GetHashCode()
        {
            return Convert.ToInt32(this.ID);
        }
    }
}

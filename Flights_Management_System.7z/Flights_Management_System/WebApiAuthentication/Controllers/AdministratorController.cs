﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http.Description;
using FlightsManagementSystem;
using FlightsManagementSystem.Facade;
using FlightsManagementSystem.Login.InterfaceLogin;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace WebApiAuthentication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize(Roles = "Administrator")]
    public class AdministratorController : ControllerBase
    {
        #region Create New Administrator
        /// <summary>
        /// CreateNewAdministrator /new/adminUsername
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [ResponseType(typeof(Administrator))]
        [Route("new/adminUsername", Name = "GreateNewAdmin")]
        [HttpPost]
        public ActionResult<IEnumerable<string>> GreateNewAdmin([FromBody]Administrator admin)
        {
            BasicAuthenticationController.CreatingAdminApiTest(); // for testing web api only
            FlyingCenterSystem.TryLogin(FlightCenterConfig.ADMIN_USER_NAME, FlightCenterConfig.ADMIN_PASSWORD, out ILoginToken token, out FacadeBase user);
            LoginToken<Administrator> adminToken = token as LoginToken<Administrator>;
            LoggedInAdministratorFacade adminFacade = user as LoggedInAdministratorFacade;
            try
            {
                if (admin == null)
                {
                    return NotFound();
                }
                adminFacade.CreateNewAdmin(adminToken, admin);
                return Ok(admin.USER_NAME);
            }

            catch (Exception exeption)
            {
                return BadRequest(exeption.ToString());
            }
        }
        #endregion


        #region Update Admin
        /// <summary>
        /// UpdateAdminDetails /update/
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [ResponseType(typeof(Administrator))]
        [Route("update/{adminUsername}", Name = "UpdateAdminDetails")]
        [HttpPut]
        public ActionResult<IEnumerable<string>> UpdateAdminDetails([FromBody]Administrator admin, [FromRoute] string adminUsername)
        {
            BasicAuthenticationController.CreatingAdminApiTest(); // for testing web api only
            FlyingCenterSystem.TryLogin(FlightCenterConfig.ADMIN_USER_NAME, FlightCenterConfig.ADMIN_PASSWORD, out ILoginToken token, out FacadeBase user);
            LoginToken<Administrator> adminToken = token as LoginToken<Administrator>;
            LoggedInAdministratorFacade adminFacade = user as LoggedInAdministratorFacade;

            try
            {
                if (admin == null)
                {
                    return NotFound();
                }
                else if (adminUsername == null)
                    return BadRequest($"Admin user name {adminUsername} is wrong, please insert correct one");
                else
                    admin.USER_NAME = adminUsername;
                adminFacade.UpdateAdminDetails(adminToken, admin);
                return Ok(admin.USER_NAME);
            }

            catch (Exception exeption)
            {
                return BadRequest(exeption.ToString());
            }
        }
        #endregion

        #region Remove Admin
        /// <summary>
        /// RemoveAirline /remove/
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [ResponseType(typeof(Administrator))]
        [Route("remove/{adminUsername}", Name = "DeleteAdmin")]
        [HttpDelete]
        public ActionResult<IEnumerable<string>> DeleteAdmin([FromRoute]string adminUsername)
        {
            BasicAuthenticationController.CreatingAdminApiTest(); // for testing web api only
            FlyingCenterSystem.TryLogin(FlightCenterConfig.ADMIN_USER_NAME, FlightCenterConfig.ADMIN_PASSWORD, out ILoginToken token, out FacadeBase user);
            LoginToken<Administrator> adminToken = token as LoginToken<Administrator>;
            LoggedInAdministratorFacade adminFacade = user as LoggedInAdministratorFacade;
            Administrator admin = adminFacade.GetAdminByUserName(adminToken, adminUsername);
            try
            {
                if (adminUsername == null)
                    return BadRequest($"Admin user name {adminUsername} is wrong, please insert correct one");
                else
                    adminFacade.RemoveAdmin(adminToken, admin);
                return Ok(admin.USER_NAME);
            }

            catch (Exception exeption)
            {
                return BadRequest(exeption.ToString());
            }
        }
        #endregion

        #region Create New Airline
        /// <summary>
        /// CreateNewAirline /airline/new/
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [ResponseType(typeof(AirlineCompany))]
        [Route("airline/new/airlineName", Name = "GreateNewAirline")]
        [HttpPost]
        public ActionResult<IEnumerable<string>> GreateNewAirline([FromBody]AirlineCompany airline)
        {
            BasicAuthenticationController.CreatingAdminApiTest(); // for testing web api only
            FlyingCenterSystem.TryLogin(FlightCenterConfig.ADMIN_USER_NAME, FlightCenterConfig.ADMIN_PASSWORD, out ILoginToken token, out FacadeBase user);
            LoginToken<Administrator> adminToken = token as LoginToken<Administrator>;
            LoggedInAdministratorFacade adminFacade = user as LoggedInAdministratorFacade;
            try
            {
                if (airline == null)
                {
                    return NotFound();
                }
                adminFacade.CreateNewAirline(adminToken, airline);
                return Ok(airline.AIRLINE_NAME);
            }

            catch (Exception exeption)
            {
                return BadRequest(exeption.ToString());
            }
        }
        #endregion

        #region Update Airline
        /// <summary>
        /// RemoveAirlineDetails /airline/update/
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [ResponseType(typeof(AirlineCompany))]
        [Route("airline/update/{airlineName}", Name = "UpdateAirlineDetails")]
        [HttpPut]
        public ActionResult<IEnumerable<string>> UpdateAirlineDetails([FromBody]AirlineCompany airline, [FromRoute] string airlineName)
        {
            BasicAuthenticationController.CreatingAdminApiTest(); // for testing web api only
            FlyingCenterSystem.TryLogin(FlightCenterConfig.ADMIN_USER_NAME, FlightCenterConfig.ADMIN_PASSWORD, out ILoginToken token, out FacadeBase user);
            LoginToken<Administrator> adminToken = token as LoginToken<Administrator>;
            LoggedInAdministratorFacade adminFacade = user as LoggedInAdministratorFacade;

            try
            {
                if (airline == null)
                {
                    return NotFound();
                }
                else if (airlineName == null)
                    return BadRequest($"Airline name {airlineName} is wrong, please insert correct one");
                else
                    airline.AIRLINE_NAME = airlineName;
                adminFacade.UpdateAirlineDetails(adminToken, airline);
                return Ok(airline.AIRLINE_NAME);
            }

            catch (Exception exeption)
            {
                return BadRequest(exeption.ToString());
            }
        }
        #endregion

        #region Remove Airline
        /// <summary>
        /// RemoveAirline /airline/remove/
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [ResponseType(typeof(AirlineCompany))]
        [Route("airline/remove/{airlineName}", Name = "DeleteAirline")]
        [HttpDelete]
        public ActionResult<IEnumerable<string>> DeleteAirline([FromRoute]string airlineName)
        {
            BasicAuthenticationController.CreatingAdminApiTest(); // for testing web api only
            FlyingCenterSystem.TryLogin(FlightCenterConfig.ADMIN_USER_NAME, FlightCenterConfig.ADMIN_PASSWORD, out ILoginToken token, out FacadeBase user);
            LoginToken<Administrator> adminToken = token as LoginToken<Administrator>;
            LoggedInAdministratorFacade adminFacade = user as LoggedInAdministratorFacade;
            AirlineCompany airline = adminFacade.GetAirlineByName(adminToken, airlineName);
            try
            {
                if (airlineName == null)
                    return BadRequest($"Airline name {airlineName} is wrong, please insert correct one");
                else
                    adminFacade.RemoveAirline(adminToken, airline);
                return Ok(airline.AIRLINE_NAME);
            }

            catch (Exception exeption)
            {
                return BadRequest(exeption.ToString());
            }
        }
        #endregion

        #region Create New Customer
        /// <summary>
        /// CreateNewCustomer /customer/new/
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [ResponseType(typeof(Customer))]
        [Route("customer/new/customerUsername", Name = "GreateNewCustomer")]
        [HttpPost]
        public ActionResult<IEnumerable<string>> GreateNewCustomer([FromBody]Customer customer)
        {
            BasicAuthenticationController.CreatingAdminApiTest(); // for testing web api only
            FlyingCenterSystem.TryLogin(FlightCenterConfig.ADMIN_USER_NAME, FlightCenterConfig.ADMIN_PASSWORD, out ILoginToken token, out FacadeBase user);
            LoginToken<Administrator> adminToken = token as LoginToken<Administrator>;
            LoggedInAdministratorFacade adminFacade = user as LoggedInAdministratorFacade;

            try
            {
                if (customer == null)
                {
                    return NotFound();
                }
                adminFacade.CreateNewCustomer(adminToken, customer);
                return Ok(customer.USER_NAME);
            }

            catch (Exception exeption)
            {
                return BadRequest(exeption.ToString());
            }
        }
        #endregion

        #region Update Customer
        /// <summary>
        /// UpdateCustomerDetails /customer/update/
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [ResponseType(typeof(Customer))]
        [Route("customer/update/{userName}", Name = "UpdateCustomerDetails")]
        [HttpPut]
        public ActionResult<IEnumerable<string>> UpdateCustomerDetails([FromBody]Customer customer, [FromRoute]string userName)
        {
            BasicAuthenticationController.CreatingAdminApiTest(); // for testing web api only
            FlyingCenterSystem.TryLogin(FlightCenterConfig.ADMIN_USER_NAME, FlightCenterConfig.ADMIN_PASSWORD, out ILoginToken token, out FacadeBase user);
            LoginToken<Administrator> adminToken = token as LoginToken<Administrator>;
            LoggedInAdministratorFacade adminFacade = user as LoggedInAdministratorFacade;

            try
            {
                if (customer == null)
                {
                    return NotFound();
                }
                else if (userName == null)
                    return BadRequest($"Customer name {userName} is wrong, please insert correct one");
                else
                    customer.USER_NAME = userName;
                adminFacade.UpdateCustomerDetails(adminToken, customer);
                return Ok(customer.USER_NAME);
            }

            catch (Exception exeption)
            {
                return BadRequest(exeption.ToString());
            }
        }
        #endregion

        #region Remove Customer
        /// <summary>
        /// RemoveCustomerDetails /customer/remove/
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [ResponseType(typeof(Customer))]
        [Route("customer/remove/{userName}", Name = "DeleteCustomer")]
        [HttpDelete]
        public ActionResult<IEnumerable<string>> DeleteCustomer([FromRoute]string userName)
        {
            BasicAuthenticationController.CreatingAdminApiTest(); // for testing web api only
            FlyingCenterSystem.TryLogin(FlightCenterConfig.ADMIN_USER_NAME, FlightCenterConfig.ADMIN_PASSWORD, out ILoginToken token, out FacadeBase user);
            LoginToken<Administrator> adminToken = token as LoginToken<Administrator>;
            LoggedInAdministratorFacade adminFacade = user as LoggedInAdministratorFacade;
            Customer customer = adminFacade.GetCustomerByUserName(adminToken, userName);
            try
            {
                if (userName == null)
                    return BadRequest($"Customer name {userName} is wrong, please try again");
                else
                    adminFacade.RemoveCustomer(adminToken, customer);
                return Ok(customer.USER_NAME);
            }

            catch (Exception exeption)
            {
                return BadRequest(exeption.ToString());
            }
        }
        #endregion
    }
}

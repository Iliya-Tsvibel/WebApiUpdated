﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightsManagementSystem
{
    // This is the POCO Class
    public class Administrator : IUser, IPoco
    {

        public long ID { get; set; }
        public string FIRST_NAME { get; set; }
        public string LAST_NAME { get; set; }
        public string USER_NAME { get; set; }
        public string PASSWORD { get; set; }

        // Constructor without parameters
        public Administrator()
        {

        }
        // Constructor with parameters
        public Administrator(long iD, string uSER_NAME, string pASSWORD)
        {
            ID = iD;
            USER_NAME = uSER_NAME;
            PASSWORD = pASSWORD;
        }

        // Constructor with login parameters
        public Administrator(string uSER_NAME, string pASSWORD)
        {
            USER_NAME = uSER_NAME;
            PASSWORD = pASSWORD;
        }

        // Equals check
        // This Function Override The Real Operator == and Check If This ID And Other ID Are Equals
        public static bool operator ==(Administrator thisAdministrator, Administrator otherAdministrator)
        {
 
            if (ReferenceEquals(thisAdministrator, null) && ReferenceEquals(otherAdministrator, null))
                return true;
            if (ReferenceEquals(thisAdministrator, null) || ReferenceEquals(otherAdministrator, null))
                return false;

            return (thisAdministrator.ID == otherAdministrator.ID);
        }

        // This Function Override The Real Operator != and Check If This ID And Other ID are not Equals
        public static bool operator !=(Administrator thisAdministrator, Administrator otherAdministrator)
        {
            return !(thisAdministrator == otherAdministrator);
        }

        // This Function Override The Real Function Equals And Compair Between This ID and Other ID
        public override bool Equals(object obj)
        {
            if (obj == null)
                return false;
            Administrator ad = obj as Administrator;
            if (ad == null)
                return false;
            return ID == ad.ID;
        }

        public override int GetHashCode()
        {
            return Convert.ToInt32(this.ID);
        }


    }
}

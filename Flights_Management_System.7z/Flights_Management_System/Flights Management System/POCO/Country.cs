﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightsManagementSystem
{
    public class Country : IPoco
    {
        // This is the POCO Class
        public long ID { get; set; }
        public string COUNTRY_NAME { get; set; }

        // Constructor without parameters
        public Country()
        {

        }

        // Constructor with parameters
        public Country(long iD, string cOUNTRY_NAME)
        {
            ID = iD;
            COUNTRY_NAME = cOUNTRY_NAME;
        }
        // Constructor with parameters for test
        public Country(string cOUNTRY_NAME)
        {
            
            COUNTRY_NAME = cOUNTRY_NAME;
        }


        // Equals check
        // This Function Override The Real Operator == and Check If This ID And Other ID Are Equals
        public static bool operator ==(Country thisCountry, Country otherCountry)
        {
            if (ReferenceEquals(thisCountry, null) && ReferenceEquals(otherCountry, null))
                return true;
            if (ReferenceEquals(thisCountry, null) || ReferenceEquals(otherCountry, null))
                return false;

            return (thisCountry.ID == otherCountry.ID);
        }

        // This Function Override The Real Operator != and Check If This ID And Other ID are not Equals
        public static bool operator !=(Country thisCountry, Country otherCountry)
        {
            return !(thisCountry == otherCountry);
        }

        // This Function Override The Real Function Equals And Compair Between This ID and Other ID
        public override bool Equals(object obj)
        {
            if (obj == null)
                return false;
            Country co = obj as Country;
            if (co == null)
                return false;
            return ID == co.ID;
        }


        //Hash Code override
        public override int GetHashCode()
        {
            return Convert.ToInt32(this.ID);
        }
    }
}

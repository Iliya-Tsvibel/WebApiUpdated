﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightsManagementSystem
{
    public class Customer : IPoco, IUser
    {
        // This is the POCO Class
        public long ID { get; set; }
        public string FIRST_NAME { get; set; }
        public string LAST_NAME { get; set; }
        public string USER_NAME { get; set; }
        public string PASSWORD { get; set; }
        public string ADDRESS { get; set; }
        public string PHONE_NO { get; set; }
        public string CREDIT_CARD_NUMBER { get; set; }

        // Constructor without parameters
        public Customer()
        {

        }
        // Constructor with parameters
        public Customer(long iD, string fIRST_NAME, string lAST_NAME, string uSER_NAME, string pASSWORD, string aDDRESS, string pHONE_NO, string cREDIT_CARD_NUMBER)
        {
            ID = iD;
            FIRST_NAME = fIRST_NAME;
            LAST_NAME = lAST_NAME;
            USER_NAME = uSER_NAME;
            PASSWORD = pASSWORD;
            ADDRESS = aDDRESS;
            PHONE_NO = pHONE_NO;
            CREDIT_CARD_NUMBER = cREDIT_CARD_NUMBER;
        }
        // Constructor for test without ID parameter
        public Customer(string fIRST_NAME, string lAST_NAME, string uSER_NAME, string pASSWORD, string aDDRESS, string pHONE_NO, string cREDIT_CARD_NUMBER)
        {
            FIRST_NAME = fIRST_NAME;
            LAST_NAME = lAST_NAME;
            USER_NAME = uSER_NAME;
            PASSWORD = pASSWORD;
            ADDRESS = aDDRESS;
            PHONE_NO = pHONE_NO;
            CREDIT_CARD_NUMBER = cREDIT_CARD_NUMBER;
        }

        // Constructor with login parameters
        public Customer(string uSER_NAME, string pASSWORD)
        {

            USER_NAME = uSER_NAME;
            PASSWORD = pASSWORD;

        }


        public bool Equals(Customer other)
        {
            return other != null &&
                   ID == other.ID;
        }



        // Equals check
        // This Function Override The Real Operator == and Check If This ID And Other ID Are Equals
        public static bool operator ==(Customer thisCustomer, Customer otherCustomer)
        {
            if (ReferenceEquals(thisCustomer, null) && ReferenceEquals(otherCustomer, null))
                return true;
            if (ReferenceEquals(thisCustomer, null) || ReferenceEquals(otherCustomer, null))
                return false;

            return (thisCustomer.ID == otherCustomer.ID);
        }

        // This Function Override The Real Operator != and Check If This ID And Other ID are not Equals
        public static bool operator !=(Customer thisCustomer, Customer otherCustomer)
        {
            return !(thisCustomer == otherCustomer);
        }

        // This Function Override The Real Function Equals And Compair Between This ID and Other ID
        public override bool Equals(object obj)
        {
            if (obj == null)
                return false;
            Customer cu = obj as Customer;
            if (cu == null)
                return false;
            return ID == cu.ID;
        }

        //Hash Code override
        public override int GetHashCode()
        {
            return Convert.ToInt32(this.ID);
        }
    }
}

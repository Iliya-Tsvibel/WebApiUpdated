﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightsManagementSystem
{
    //Marker Interface Only For User Classes
    public interface IUser
    {

    }
    
}

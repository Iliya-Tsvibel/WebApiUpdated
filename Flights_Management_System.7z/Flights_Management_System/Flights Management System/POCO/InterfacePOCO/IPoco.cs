﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightsManagementSystem
{
    //Marker Interface For Any Poco Classes
    public interface IPoco
    {
    }
}

﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightsManagementSystem.DAO
{
    public class TicketDAOMSSQL : ITicketDAO
    {
        public long Add(Ticket t)
        {
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("CREATE_NEW_TICKET", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@FLIGHT_ID", t.FLIGHT_ID));
                    cmd.Parameters.Add(new SqlParameter("@CUSTOMER_ID", t.CUSTOMER_ID));
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                    return t.ID = (long)cmd.ExecuteScalar();
                }
            }
        }
        public Ticket Get(int id)
        {
            Ticket TicketById = new Ticket();
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("GET_TICKETS_BY_ID", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@ID", id));
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            TicketById.ID = id;
                            TicketById.CUSTOMER_ID = (long)reader["CUSTOMER_ID"];
                            TicketById.FLIGHT_ID = (long)reader["FLIGHT_ID"];
                        }
                    }
                }

            }
            return TicketById;
        }
        public IList<Ticket> GetAll()
        {
            List<Ticket> AllTickets = new List<Ticket>();
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT_ALL_TICKETS", sqlConnection))
                {
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    using (SqlDataReader read = cmd.ExecuteReader())
                    {
                        while (read.Read())
                        {
                            Ticket Ticket = new Ticket();
                            Ticket.ID = (long)read["ID"];
                            Ticket.FLIGHT_ID = (long)read["FLIGHT_ID"];
                            Ticket.CUSTOMER_ID = (long)read["CUSTOMER_ID"];
                            AllTickets.Add(Ticket);
                        }
                    }
                }
            }
            return AllTickets;
        }
        public bool DoesTicketExist(long ticketID)
        {
            int result;
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                SqlCommand FindAirlineByName = new SqlCommand("GET_TICKETS_BY_ID", sqlConnection);
                FindAirlineByName.Parameters.Add(new SqlParameter("@ID", ticketID));
                FindAirlineByName.Connection.Open();
                FindAirlineByName.CommandType = CommandType.StoredProcedure;
                SqlDataReader sqlDataReader = FindAirlineByName.ExecuteReader(CommandBehavior.Default);

                if (sqlDataReader.Read() == true)
                {
                    result = 1;
                }
                else
                    result = 0;


                FindAirlineByName.Connection.Close();

                if (result == 1)
                {
                    return true;
                }
                else
                    return false;

            }

        }
        public void Remove(Ticket t)
        {
            //int _result = 0;
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("CANCEL_TICKET", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@ID", t.ID));

                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                   /* _result = */cmd.ExecuteNonQuery();
                }
            }
            //return _result;
        }
        public void Update(Ticket t)
        {
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("UPDATE_TICKETS_DETAILS", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@ID", t.ID));
                    cmd.Parameters.Add(new SqlParameter("@FLIGHT_ID", t.FLIGHT_ID));
                    cmd.Parameters.Add(new SqlParameter("@CUSTOMER_ID", t.CUSTOMER_ID));

                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                }

            }
        }
        private bool DoesFlightExistByFlihtID(long fLIGHT_ID)
        {
            int result;
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                SqlCommand FindFlightByName = new SqlCommand("DOES_FLIGHT_EXIST", sqlConnection);
                FindFlightByName.Parameters.Add(new SqlParameter("@ID", fLIGHT_ID));
                FindFlightByName.Connection.Open();
                FindFlightByName.CommandType = CommandType.StoredProcedure;
                SqlDataReader sqlDataReader = FindFlightByName.ExecuteReader(CommandBehavior.Default);

                if (sqlDataReader.Read() == true)
                {
                    result = 1;
                }
                else
                    result = 0;


                FindFlightByName.Connection.Close();

                if (result == 1)
                {
                    return true;
                }
                else
                    return false;

            }
        }

        public int CheckInventory(long fLIGHT_ID)
        {
            int inventory = 0;
            if (!DoesFlightExistByFlihtID(fLIGHT_ID))
            {
                throw new InsufficientDataException();
            }
            
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                SqlCommand FindFlightByName = new SqlCommand("CHECK_INVENTORY", sqlConnection);
                FindFlightByName.Parameters.Add(new SqlParameter("@ID", fLIGHT_ID));
                FindFlightByName.Connection.Open();
                FindFlightByName.CommandType = CommandType.StoredProcedure;
                SqlParameter returnParameter = new SqlParameter();
                returnParameter.SqlDbType = SqlDbType.Int;
                returnParameter.Direction = ParameterDirection.Output;
                returnParameter.ParameterName = "@REMAINING_TICKETS";
                SqlDataReader sqlDataReader = FindFlightByName.ExecuteReader(CommandBehavior.Default);

                while (sqlDataReader.Read() == true)
                {
                    inventory = (int)returnParameter.Value;
                }

                FindFlightByName.Connection.Close();
                
            }

            return inventory;
        }


        public IList<Ticket> GetTicketsByAirlineComapny(AirlineCompany airline)
        {
            List<Ticket> ticket = new List<Ticket>();
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                sqlConnection.Open();
                SqlCommand FindTicketsAirline = new SqlCommand("GET_TICKETS_BY_AIRLINE", sqlConnection);
                FindTicketsAirline.Parameters.Add(new SqlParameter("@ID", airline.ID));
                FindTicketsAirline.CommandType = CommandType.StoredProcedure;
                sqlConnection.InfoMessage += delegate (object sender, SqlInfoMessageEventArgs e)
                {
                    Console.WriteLine(e.Message);
                };

                SqlDataReader sqlDataReader = FindTicketsAirline.ExecuteReader(CommandBehavior.Default);

                while (sqlDataReader.Read() == true)
                {
                    ticket.Add(new Ticket
                    {
                        ID = (long)sqlDataReader["ID"],
                        FLIGHT_ID = (long)sqlDataReader["FLIGHT_ID"],
                        CUSTOMER_ID = (long)sqlDataReader["CUSTOMER_ID"]
                    });
                }

                FindTicketsAirline.Connection.Close();
            }
            return ticket;
        }

            public IList<Ticket> GetTicketsByCustomer(Customer customer)
            {
                List<Ticket> ticket = new List<Ticket>();
                using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
                {
                   sqlConnection.Open();
                   SqlCommand FindTicketsByCustomer = new SqlCommand("GET_TICKETS_BY_USER", sqlConnection);
                   FindTicketsByCustomer.Parameters.Add(new SqlParameter("@CUSTOMER_ID", customer.ID));
                   FindTicketsByCustomer.CommandType = CommandType.StoredProcedure;
                   sqlConnection.InfoMessage += delegate (object sender, SqlInfoMessageEventArgs e)
                   {
                       Console.WriteLine(e.Message);
                   };

                   SqlDataReader sqlDataReader = FindTicketsByCustomer.ExecuteReader(CommandBehavior.Default);

                   while (sqlDataReader.Read() == true)
                   {
                       ticket.Add(new Ticket
                       {
                           ID = (long)sqlDataReader["ID"],
                           FLIGHT_ID = (long)sqlDataReader["FLIGHT_ID"],
                           CUSTOMER_ID = (long)sqlDataReader["CUSTOMER_ID"]
                       });
                   }

                   FindTicketsByCustomer.Connection.Close();
                }
                   return ticket;
            }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http.Description;
using FlightsManagementSystem;
using FlightsManagementSystem.Facade;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace WebApiAuthentication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AnonymousController : ControllerBase
    {

        AnonymousUserFacade _anonymous = new AnonymousUserFacade();

        #region Get
        /// <summary>
        /// GetAllFlight /flight
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [ResponseType(typeof(IList<Flight>))]
        [Route("flight", Name = "GeAllFlights")]
        [HttpGet]
        public ActionResult<IEnumerable<string>> GeAllFlights()
        {
            IList<Flight> flights = _anonymous.GetAllFlights();
            if (flights == null)
            {
                return NotFound();
            }
            return Ok(flights);
        }

        /// <summary>
        /// GetAllAirlines /airline
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [ResponseType(typeof(IList<AirlineCompany>))]
        [Route("airline", Name = "GeAllAirlines")]
        [HttpGet]
        public ActionResult<IEnumerable<string>> GeAllAirlines()
        {
            IList<AirlineCompany> airlines = _anonymous.GetAllAirlineCompanies();
            if (airlines == null)
            {
                return NotFound();
            }
            return Ok(airlines);
        }

        /// <summary>
        /// GetAllFlightsVacancy /flightsVacancy
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [ResponseType(typeof(Dictionary<Flight, int>))]
        [Route("flightVacancy", Name = "GeAllFlightVacancy")]
        [HttpGet]
        public ActionResult<IEnumerable<string>> GeAllFlightVacancy()
        {
            Dictionary<Flight, int> flights = _anonymous.GetAllFlightsVacancy();
            if (flights == null)
            {
                return NotFound();
            }
            return Ok(flights);
        }

        /// <summary>
        /// Get specific flight by id
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [ResponseType(typeof(Flight))]
        [Route("flight/{id}", Name = "GeById")]
        [HttpGet]
        public ActionResult<string> GetById(int id)
        {
            Flight flights = _anonymous.GetFlightById(id);
            if (flights == null)
            {
                return NotFound();
            }
            return Ok(flights);
        }


        /// <summary>
        /// Get specific flight by origyn country
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [ResponseType(typeof(IList<Flight>))]
        [Route("flight/origynCountryId/{countryCode}", Name = "GetByOrigynCountryId")]
        [HttpGet]
        public ActionResult<string> GetByOrigynCountryId(long countryCode)
        {
            IList<Flight> flights = _anonymous.GetFlightsByOriginCountry(countryCode);
            if (flights == null)
            {
                return NotFound();
            }
            return Ok(flights);
        }

        /// <summary>
        /// Get specific flight by destination country
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [ResponseType(typeof(IList<Flight>))]
        [Route("flight/destinationCountryId/{countryCode}", Name = "GetByDestinationCountryId")]
        [HttpGet]
        public ActionResult<string> GetByDestinationCountryId(long countryCode)
        {
            IList<Flight> flights = _anonymous.GetFlightsByDestinationCountry(countryCode);
            if (flights == null)
            {
                return NotFound();
            }
            return Ok(flights);
        }

        /// <summary>
        /// Get specific flight by departure time
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [ResponseType(typeof(IList<Flight>))]
        [Route("flight/departureTime/{departureDate}", Name = "GetByDepartureTime")]
        [HttpGet]
        public ActionResult<string> GetByDepartureTime(DateTime departureDate)
        {
            IList<Flight> flights = _anonymous.GetFlightsByDepatrureDate(departureDate);
            if (flights == null)
            {
                return NotFound();
            }
            return Ok(flights);
        }

        /// <summary>
        /// Get specific flight by landing time
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [ResponseType(typeof(IList<Flight>))]
        [Route("flight/landingTime/{landingDate}", Name = "GetByLandingTime")]
        [HttpGet]
        public ActionResult<string> GetByLandingTime(DateTime landingDate)
        {
            IList<Flight> flights = _anonymous.GetFlightsByLandingDate(landingDate);
            if (flights == null)
            {
                return NotFound();
            }
            return Ok(flights);
        }
        #endregion
    }
}

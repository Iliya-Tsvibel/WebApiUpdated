﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http.Description;
using System.Web.Http.Filters;
using FlightsManagementSystem;
using FlightsManagementSystem.Facade;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TestFlightManagementSystem;

namespace WebApiAuthentication.Controllers
{
    internal class BasicAuthenticationController : AuthorizationFilterAttribute
    {
        // For admin api test
        static public void CreatingAdminApiTest()
        {
            LoginToken<Administrator> adminToken = new LoginToken<Administrator>();
            LoggedInAdministratorFacade adminFacade = new LoggedInAdministratorFacade();
            Administrator newAdmin = new Administrator { FIRST_NAME = FlightCenterConfig.ADMIN_NAME, LAST_NAME = FlightCenterConfig.ADMIN_LAST_NAME, USER_NAME = FlightCenterConfig.ADMIN_USER_NAME, PASSWORD = FlightCenterConfig.ADMIN_PASSWORD };
            adminFacade.CreateNewAdmin(adminToken, newAdmin);
        }


        // For airline api test
        static public void CreatingAirlineApiTest()
        {
            LoginToken<Administrator> adminToken = new LoginToken<Administrator>();
            LoggedInAdministratorFacade adminFacade = new LoggedInAdministratorFacade();
            LoginToken<AirlineCompany> companyToken = new LoginToken<AirlineCompany>();
            LoggedInAirlineFacade airlineFacade = new LoggedInAirlineFacade();
            Country newCountry = new Country { COUNTRY_NAME = FlightCenterConfig.COUNTRY_NAME };
            adminFacade.CreateNewCountry(adminToken, newCountry);
            AirlineCompany newCompany = new AirlineCompany { AIRLINE_NAME = FlightCenterConfig.AIRLINE_NAME, USER_NAME = FlightCenterConfig.AIRLINE_USER_NAME, PASSWORD = FlightCenterConfig.AIRLINE_PASSWORD, COUNTRY_CODE = adminFacade.GetCountryByName(FlightCenterConfig.COUNTRY_NAME).ID };
            adminFacade.CreateNewAirline(adminToken, newCompany);
        }
        // For customer api test
        static public void CreatingCustomerApiTest()
        {
            AnonymousUserFacade anonymousFacade = new AnonymousUserFacade();
            Customer newCustomer = new Customer { FIRST_NAME = FlightCenterConfig.CUSTOMER_NAME, LAST_NAME = FlightCenterConfig.CUSTOMER_LAST_NAME, USER_NAME = FlightCenterConfig.CUSTOMER_USER_NAME, PASSWORD = FlightCenterConfig.CUSTOMER_PASSWORD };
            anonymousFacade.CreateNewCustomer(newCustomer);
        }


    }
}

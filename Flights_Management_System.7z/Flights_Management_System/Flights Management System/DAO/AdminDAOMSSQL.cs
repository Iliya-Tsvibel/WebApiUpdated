﻿using FlightsManagementSystem.DAO.InterfaceDAO;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightsManagementSystem.DAO
{
    public class AdminDAOMSSQL : IAdminDAO
    {
        public long Add(Administrator t)
        {
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("CREATE_NEW_ADMINISTRATOR", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@FIRST_NAME", t.FIRST_NAME));
                    cmd.Parameters.Add(new SqlParameter("@LAST_NAME", t.LAST_NAME));
                    cmd.Parameters.Add(new SqlParameter("@USER_NAME", t.USER_NAME));
                    cmd.Parameters.Add(new SqlParameter("@PASSWORD", t.PASSWORD));
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                    return t.ID = (long)cmd.ExecuteScalar();
                }
            }
        }

        public void Update(Administrator ad)
        {
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("UPDATE_ADMIN_DETAILS", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@FIRST_NAME", ad.FIRST_NAME));
                    cmd.Parameters.Add(new SqlParameter("@LAST_NAME", ad.LAST_NAME));
                    cmd.Parameters.Add(new SqlParameter("@USER_NAME", ad.USER_NAME));
                    cmd.Parameters.Add(new SqlParameter("@PASSWORD", ad.PASSWORD));
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                    cmd.Connection.Close();
                }
            }
        }

        public void Remove(Administrator ad)
        {
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("REMOVE_ADMIN", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@USER_NAME", ad.USER_NAME));
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                    cmd.Connection.Close();
                }
            }
        }

        public bool DoesUsernameExist(string userName)
        {
            int result;

            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                SqlCommand FindUserByName = new SqlCommand("DOES_USERNAME_EXIST", sqlConnection);
                FindUserByName.Parameters.Add(new SqlParameter("@USER_NAME", userName));
                FindUserByName.Connection.Open();
                FindUserByName.CommandType = CommandType.StoredProcedure;
                SqlDataReader sqlDataReader = FindUserByName.ExecuteReader(CommandBehavior.Default);

                if (sqlDataReader.Read() == true)
                {
                    result = 1;
                }
                else
                    result = 0;


                FindUserByName.Connection.Close();

                if (result == 1)
                {
                    return true;
                }
                else
                    return false;

            }

        }

        public Administrator Get(int id)
        {
            throw new NotImplementedException();
        }

        public IList<Administrator> GetAll()
        {
            throw new NotImplementedException();
        }

        // Change Password Of Current Administrator.
        public void ChangePassword(Administrator administrator)
        {
            using (SqlConnection connection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand($"Update AirLineCompanies Set Password = '{administrator.PASSWORD}' Where Id = {administrator.ID}", connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }
        // Search Administrator By UserName.
        public Administrator GetAdminByUserName(string userName)
        {

            Administrator adminName = null;
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                SqlCommand FindCustomerByUsername = new SqlCommand("GET_ADMINISTRATOR_BY_USER_NAME", sqlConnection);
                FindCustomerByUsername.Parameters.Add(new SqlParameter("@USER_NAME", userName));
                FindCustomerByUsername.Connection.Open();
                FindCustomerByUsername.CommandType = CommandType.StoredProcedure;
                sqlConnection.InfoMessage += delegate (object sender, SqlInfoMessageEventArgs e)
                {
                    Console.WriteLine(e.Message);
                };

                SqlDataReader sqlDataReader = FindCustomerByUsername.ExecuteReader(CommandBehavior.Default);

                if (sqlDataReader.Read() == true)
                {
                    adminName = new Administrator
                    {
                        FIRST_NAME = (string)sqlDataReader["FIRST_NAME"],
                        LAST_NAME = (string)sqlDataReader["LAST_NAME"],
                        PASSWORD = (string)sqlDataReader["PASSWORD"],
                        USER_NAME = (string)sqlDataReader["USER_NAME"],
                    };

                }

                FindCustomerByUsername.Connection.Close();
            }
            return adminName;
        }

        public Administrator GetByUserName(string userName)
        {
            throw new NotImplementedException();
        }

        public AirlineCompany GetAirlineById(int id)
        {
            throw new NotImplementedException();
        }

        public AirlineCompany GetAirlineByUserName(string userName)
        {
            throw new NotImplementedException();
        }

        public IList<AirlineCompany> GetAllAirlineByCountry(int countryId)
        {
            throw new NotImplementedException();
        }

        public IList<AirlineCompany> GetAllAirelineCompanies()
        {
            throw new NotImplementedException();
        }

        public Customer GetCustomerById(int id)
        {
            throw new NotImplementedException();
        }

        public Customer GetCustomerByUserName(string userName)
        {
            throw new NotImplementedException();
        }

        public IList<Customer> GetAllCustomerByAddress(string Address)
        {
            throw new NotImplementedException();
        }

        public IList<Customer> GetAllCustomerByCardNumber(int cardNumber)
        {
            throw new NotImplementedException();
        }

        public IList<Customer> GetAllCustomers()
        {
            throw new NotImplementedException();
        }
    }
}



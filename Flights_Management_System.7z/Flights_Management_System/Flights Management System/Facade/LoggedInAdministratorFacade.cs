﻿using FlightsManagementSystem.DAO;
using FlightsManagementSystem.DAO.InterfaceDAO;
using FlightsManagementSystem.Facade.InterfaceFacade;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestFlightManagementSystem;

namespace FlightsManagementSystem.Facade
{
    // Class With All The Admin functions
    public class LoggedInAdministratorFacade : AnonymousUserFacade, ILoggedInAdministratorFacade
    {
        private new IAirlineDAO _airlineDAO = new AirlineDAOMSSQL();
        private new IAdminDAO _adminDAO = new AdminDAOMSSQL();
        private new ICustomerDAO _customerDAO = new CustomerDAOMSSQL();
        private new ICountryDAO _countryDAO = new CountryDAOMSSQL();
        private new ITicketDAO _ticketDAO = new TicketDAOMSSQL();
        private new IFlightDAO _flightDAO = new FlightDAOMSSQL();

        // Create New Administrator
        public long CreateNewAdmin(LoginToken<Administrator> token, Administrator admin)
        {
            long createdID = 0;
            if (token != null)
            {
                _adminDAO.Add(admin);
            }
            return createdID;
        }

        // Update New Administrator
        public void UpdateAdminDetails(LoginToken<Administrator> token, Administrator admin)
        {
            if (token != null)
            {
                _adminDAO.Update(admin);
            }
        }

        // Remove admin
        public void RemoveAdmin(LoginToken<Administrator> token, Administrator admin)
        {
            if (token != null)
            {
                _adminDAO.Remove(admin);
            }
        }

        // Create New Airline Company
        public long CreateNewAirline(LoginToken<Administrator> token, AirlineCompany airline)
        {
            long createdID = 0;
            if (token != null)
            {
                if (_airlineDAO.DoesAirlineExist(airline.AIRLINE_NAME))
                {
                    throw new AirlineCompanyAlreadyExistsException("This airline company already exist");
                }
                    _airlineDAO.Add(airline);
            }
            return createdID;
        }
       
        // Update Details Of any Airline Company
        public void UpdateAirlineDetails(LoginToken<Administrator> token, AirlineCompany customer)
        {
            if (token != null)
            {

                //if (_airlineDAO.DoesAirlineExist(customer.AIRLINE_NAME))
                //{
                _airlineDAO.Update(customer);
                //}
                //throw new AirlineCompanyDoesNotExistException("This airline company doesn't exist. Please insert correct name");

            }
        }
        // Remove airline company
        public void RemoveAirline(LoginToken<Administrator> token, AirlineCompany airline)
        {
            if (!(_airlineDAO.DoesAirlineExist(airline.AIRLINE_NAME)))
            {
                throw new AirlineCompanyDoesNotExistException("This airline not exist");
            }
            if (token != null)
            {
                
                _airlineDAO.Remove(airline);

            }
        }

        // Creating new customer
        public long CreateNewCustomer(LoginToken<Administrator> token, Customer customer)
        {
            //if (token.User is Administrator)
            //{
            //    _customerDAO.Add(customer);
            //}

            if (token != null && token.User != null)
            {
                return customer.ID = _customerDAO.Add(customer);
            }
            return 0;
        }
        // Updating customer's details
        public void UpdateCustomerDetails(LoginToken<Administrator> token, Customer customer)
        {
            if (token != null)
            {
                _customerDAO.Update(customer);
            }
        }

        // Remove customer
        public void RemoveCustomer(LoginToken<Administrator> token, Customer customer)
        {
            if (token != null)
            {
                _customerDAO.Remove(customer);
            }
        }
        // Change user password
        public void ChangeMyPassword(LoginToken<Administrator> token, string oldPassword, string newPassword)
        {
            if (token != null)
            {
                if (token.User.PASSWORD.ToUpper() == oldPassword.ToUpper())
                {
                    token.User.PASSWORD = newPassword.ToUpper();
                    _adminDAO.ChangePassword(token.User);
                }
                else
                    throw new WrongPasswordException("The current password is incorrect. Please, try again");
            }
        }

        // Search Airline Company By UserName.
        public AirlineCompany GetAirlineByUserName(LoginToken<Administrator> token, string userName)
        {
            AirlineCompany airline = null;
            if (token != null)
            {
                airline = _airlineDAO.GetAirlineByUsername(userName);
            }
            return airline;
        }
        public AirlineCompany GetAirlineByName(LoginToken<Administrator> token, string name)
        {
            AirlineCompany airline = null;
            if (token != null)
            {
                airline = _airlineDAO.GetAirlineByName(name);
            }
            return airline;
        }

        public AirlineCompany GetAirlineByID(LoginToken<Administrator> token, int id)
        {
            AirlineCompany airline = null;
            if (token != null)
            {
                airline = _airlineDAO.Get(id);
            }
            return airline;
        }

        // Search Customer By UserName.
        public Customer GetCustomerByUserName(LoginToken<Administrator> token, string userName)
        {
            Customer customer = null;
            if (token != null)
            {
                customer = _customerDAO.GetCustomerByUserame(userName);
            }
            return customer;
        }

        // Search Customer By ID.
        public Customer GetCustomerByID(LoginToken<Administrator> token, int id)
        {
            Customer customer = null;
            if (token != null)
            {
                customer = _customerDAO.Get(id);
            }
            return customer;
        }

        // Search Customer By UserName.
        public Administrator GetAdminByUserName(LoginToken<Administrator> token, string userName)
        {
            Administrator admin = null;
            if (token != null)
            {
                admin = _adminDAO.GetAdminByUserName(userName);
            }
            return admin;
        }

        public long CreateNewCountry(LoginToken<Administrator> token, Country c)
        {
            //if (token.User is Administrator)
            //{
            //    _countryDAO.Add(c);
            //}
            if (token != null && token.User != null)
            {
                return c.ID = _countryDAO.Add(c);
            }
            return 0;
        }
        public Country GetCountryByName(LoginToken<Administrator> token, string name)
        {
            Country country = null;
            if (token != null)
            {
                country = _countryDAO.GetByName(name);
            }
            return country;
        }
        public IList<Customer> GetAllCustomers(LoginToken<Administrator> token)
        {
                IList<Customer> AllCustomers = _customerDAO.GetAll();
                return AllCustomers;
        }

        public Customer GetById(int id)
        {
            
            Customer AllCustomers = _customerDAO.Get(15);
            return AllCustomers;
           
        }
      
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightsManagementSystem.Facade.InterfaceFacade
{
    interface ILoggedInCustomerFacade
    {
        IList<Flight> GetAllMyFlights(LoginToken<Customer> token);
        Ticket PurchaseTicket(LoginToken<Customer> token, Ticket ticket);
        Ticket CancelTicket(LoginToken<Customer> token, Ticket ticket);
        void MofidyMyDetails(LoginToken<Customer> token, Customer customer);
        void ChangeMyPassword(LoginToken<Customer> token, string oldPassword, string newPassword);
        IList<Ticket> GetTicketByCustomer(LoginToken<Customer> token, Customer customer);
    }
}

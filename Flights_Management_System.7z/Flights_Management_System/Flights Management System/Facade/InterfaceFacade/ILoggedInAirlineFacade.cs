﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightsManagementSystem.Facade.InterfaceFacade
{
    interface ILoggedInAirlineFacade
    {
        IList<Ticket> GetAllTickets(LoginToken<AirlineCompany> token, AirlineCompany airline);
        IList<Flight> GetAllFlights(LoginToken<AirlineCompany> token, AirlineCompany airline);
        Flight CancelFlight(LoginToken<AirlineCompany> token, Flight flight);
        void CreateFlight(LoginToken<AirlineCompany> token, Flight flight);
        void UpdateFlight(LoginToken<AirlineCompany> token, Flight flight);
        void ChangeMyPassword(LoginToken<AirlineCompany> token, string oldPassword, string newPassword);
        void MofidyAirlineDetails(LoginToken<AirlineCompany> token, AirlineCompany airline);
        AirlineCompany GetAirlineByName(LoginToken<AirlineCompany> token, string name);
        Flight GetFlightById(LoginToken<AirlineCompany> token, long id);
        IList<Ticket> GetTicketByAirline(LoginToken<AirlineCompany> token, AirlineCompany airline);
        Flight GetFlightByAirline(LoginToken<AirlineCompany> token, long airlineID);
    }
}

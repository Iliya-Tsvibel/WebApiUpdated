﻿using FlightsManagementSystem.DAO;
using FlightsManagementSystem.DAO.InterfaceDAO;
using FlightsManagementSystem.Facade.InterfaceFacade;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TestFlightManagementSystem;

namespace FlightsManagementSystem.Facade
{
   public class LoggedInCustomerFacade : AnonymousUserFacade, ILoggedInCustomerFacade
    {
        private new IAirlineDAO _airlineDAO = new AirlineDAOMSSQL();
        private new IAdminDAO _adminDAO = new AdminDAOMSSQL();
        private new ICustomerDAO _customerDAO = new CustomerDAOMSSQL();
        private new ICountryDAO _countryDAO = new CountryDAOMSSQL();
        private new ITicketDAO _ticketDAO = new TicketDAOMSSQL();
        private new IFlightDAO _flightDAO = new FlightDAOMSSQL();
        public IList<Flight> GetAllMyFlights(LoginToken<Customer> token)
        {
            IList<Flight> flights_byCustomer = null;
            if (token != null)
            {
                flights_byCustomer = _flightDAO.GetFlightsByCustomer(token.User);
            }
            return flights_byCustomer;
        }
        public Ticket PurchaseTicket(LoginToken<Customer> token, Ticket ticket)
        {
            Ticket ticketByID = null;
            FlightDAOMSSQL flight = new FlightDAOMSSQL();
            if (token != null)
            {
                if (ticket != null || ticket.CUSTOMER_ID != 0 || ticket.FLIGHT_ID != 0)
                {
                        if (flight.DoesFlightExistByFlightID(ticket.FLIGHT_ID))
                        {
                             if (flight.CheckInventoryByFlightID(ticket.FLIGHT_ID))
                             {

                                 _ticketDAO.Add(ticket);
                                 _flightDAO.UpdateInventoryMinus(ticket.FLIGHT_ID);

                        }
                             else
                             throw new InsufficientInventoryException();
                        }
                        else
                        throw new FlightDoesNotExistException();
                }
                else
                throw new InsufficientDataException();
            }
            return ticketByID;
        }
        public Ticket CancelTicket(LoginToken<Customer> token, Ticket ticket)
        {
            Ticket ticketByID = null;
            if ((_ticketDAO.DoesTicketExist(ticket.ID)))
            {
                if (token != null)
                {
                    _ticketDAO.Remove(ticket);
                    _flightDAO.UpdateInventoryPlus(ticket.FLIGHT_ID);
                }
            }
            else
            throw new TicketNotExistExceprion("This ticket not exist");
            return ticketByID;

        }

        public IList<Ticket> GetTicketByCustomer(LoginToken<Customer> token, Customer customer)
        {
            IList<Ticket> ticket = null;
            if (token != null)
            {
                ticket = _ticketDAO.GetTicketsByCustomer(customer);
            }
            return ticket;
        }

        public void CancelTicketByCustomer(long customerID, Ticket ticket)
        {
            throw new NotImplementedException();
        }

        //Change Details Of Current Customer(Without Password).
        public void MofidyMyDetails(LoginToken<Customer> token, Customer customer)
        {
            if (token != null && token.User.ID == customer.ID)
            {
                _customerDAO.Update(customer);
            }
        }
        public void ChangeMyPassword(LoginToken<Customer> token, string oldPassword, string newPassword)
        {
            if (token != null)
            {
                if (token.User.PASSWORD.ToUpper() == oldPassword.ToUpper())
                {
                    token.User.PASSWORD = newPassword.ToUpper();
                    _customerDAO.ChangePassword(token.User);
                }
                else
                    throw new WrongPasswordException("The current password is incorrect. Please, try again!");
            }
        }
    }
}

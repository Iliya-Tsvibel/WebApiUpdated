﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using FlightsManagementSystem.POCO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;

namespace WebApiAuthentication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        public class AuthOptions
        {
            public const string ISSUER = "smesk.in"; // token creater

            public const string AUDIENCE = "readers"; // token user

            public const string KEY = "this_is_our_supper_long_security_key_for_token_validation_project_2018_09_07$smesk.in"; // the secret key
            public static SymmetricSecurityKey GetSymmetricSecurityKey()
            {
                return new SymmetricSecurityKey(Encoding.ASCII.GetBytes(KEY));
            }
        }

        //private List<User> people = new List<User>
        //{
        //    new User {ROLE ="admin" }
        //};
        //private ClaimsIdentity GetIdentity(string role)
        //{
        //    User person = people.FirstOrDefault(x => x.ROLE == role);
        //    if (person != null)
        //    {
        //        var claims = new List<Claim>
        //        {
        //            new Claim(ClaimsIdentity.DefaultRoleClaimType, person.ROLE)
        //        };
        //        ClaimsIdentity claimsIdentity =
        //        new ClaimsIdentity(claims, "Token", ClaimsIdentity.DefaultNameClaimType,
        //            ClaimsIdentity.DefaultRoleClaimType);
        //        return claimsIdentity;
        //    }

        //    // In case of user not exist
        //    return null;
        //}

        [HttpPost("token")]
        public ActionResult GetToken(User userToken)
        {
            //add claims
            var claims = new List<Claim>();
            //claims.Add(new Claim(ClaimTypes.Role, "Administrator"));
            //claims.Add(new Claim(ClaimTypes.Role, "Company"));
            //claims.Add(new Claim(ClaimTypes.Role, "Customer"));
            claims.Add(new Claim(ClaimTypes.Role, userToken.TYPE_OF_USER.ToString()));

            //create token
            var now = DateTime.UtcNow;
            var token = new JwtSecurityToken(
                    issuer: AuthOptions.ISSUER,
                    audience: AuthOptions.AUDIENCE,
                    notBefore: now,
                    expires: DateTime.Now.AddHours(1),
                    signingCredentials: new SigningCredentials(AuthOptions.GetSymmetricSecurityKey(), SecurityAlgorithms.HmacSha256),
                    claims: claims
                );

            //return token
            return Ok(new JwtSecurityTokenHandler().WriteToken(token));
        }
    }
}
﻿using FlightsManagementSystem.DAO;
using FlightsManagementSystem.DAO.InterfaceDAO;
using FlightsManagementSystem.Facade.InterfaceFacade;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TestFlightManagementSystem;

namespace FlightsManagementSystem.Facade
{
   public class LoggedInAirlineFacade : AnonymousUserFacade, ILoggedInAirlineFacade
    {
        private new IAirlineDAO _airlineDAO = new AirlineDAOMSSQL();
        private new IAdminDAO _adminDAO = new AdminDAOMSSQL();
        private new ICustomerDAO _customerDAO = new CustomerDAOMSSQL();
        private new ICountryDAO _countryDAO = new CountryDAOMSSQL();
        private new ITicketDAO _ticketDAO = new TicketDAOMSSQL();
        private new IFlightDAO _flightDAO = new FlightDAOMSSQL();

        public IList<Ticket> GetAllTickets(LoginToken<AirlineCompany> token, AirlineCompany airline)
        {

            if (token != null)
            {
                IList<Ticket> AllTickets = _ticketDAO.GetAll();
                return AllTickets;
            }
            return null;

        }
        public IList<Flight> GetAllFlights(LoginToken<AirlineCompany> token, AirlineCompany airline)
        {

            if (token != null)
            {
                IList<Flight> AllFlights = _flightDAO.GetAll();
                return AllFlights;
            }
            return null;

        }
       

        public Flight CancelFlight(LoginToken<AirlineCompany> token, Flight flight)
        {
            Flight flightDetails = null;
            if ((_flightDAO.DoesFlightExistByFlightID(flight.ID)))
            {
                if (token != null)
                {
                    _flightDAO.Remove(flight);
                }
            }
            else
                throw new FlightDoesNotExistException("This flight not exist");
            return flightDetails;

        }
        public void CreateFlight(LoginToken<AirlineCompany> token, Flight flight)
        {
            if (token != null && token.User.ID == flight.AIRLINECOMPANY_ID)
            {
                _flightDAO.Add(flight);
            }
                 
        }

        
        public void UpdateFlight(LoginToken<AirlineCompany> token, Flight flight)
        {
            if (token != null && token.User.ID == flight.AIRLINECOMPANY_ID)
            {
                _flightDAO.Update(flight);
            }
        }
        public void ChangeMyPassword(LoginToken<AirlineCompany> token, string oldPassword, string newPassword)
        {
            if (token != null)
            {
                if (token.User.PASSWORD.ToUpper() == oldPassword.ToUpper())
                {
                    token.User.PASSWORD = newPassword.ToUpper();
                    _airlineDAO.ChangePassword(token.User);
                }
                else
                    throw new WrongPasswordException("The current password is incorrect. Please, try again");
            }
        }
 

        public void MofidyAirlineDetails(LoginToken<AirlineCompany> token, AirlineCompany airline)
        {
            if (token != null && token.User.ID == airline.ID)
            {
                _airlineDAO.Update(airline);
            }
        }
        public AirlineCompany GetAirlineByName(LoginToken<AirlineCompany> token, string name)
        {
            AirlineCompany airline = null;
            if (token != null)
            {
                airline = _airlineDAO.GetAirlineByName(name);
            }
            return airline;
        }
        public IList<Ticket> GetTicketByAirline(LoginToken<AirlineCompany> token, AirlineCompany airline)
        {
            IList<Ticket> ticket = null;
            if (token != null)
            {
                ticket = _ticketDAO.GetTicketsByAirlineComapny(airline);
            }
            return ticket;
        }
        public Country GetCountryByName(LoginToken<AirlineCompany> token, string name)
        {
            Country country = null;
            if (token != null)
            {
                country = _countryDAO.GetByName(name);
            }
            return country;
        }
        public Flight GetFlightById(LoginToken<AirlineCompany> token, long id)
        {
            Flight flight = null;
            if (token != null)
            {
                flight = _flightDAO.GetFlightById(id);
            }
            return flight;
        }

        public Flight GetFlightByAirline(LoginToken<AirlineCompany> token, long airlineID)
        {
            Flight flight = null;
            if (token != null)
            {
                flight = _flightDAO.GetFlightByAirline(airlineID);
            }
            return flight;
        }
   }
}


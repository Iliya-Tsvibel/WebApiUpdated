﻿using System;
using System.Runtime.Serialization;

namespace FlightsManagementSystem.Facade
{
    [Serializable]
    internal class TicketCantBeCanceledException : Exception
    {
        public TicketCantBeCanceledException()
        {
        }

        public TicketCantBeCanceledException(string message) : base(message)
        {
        }

        public TicketCantBeCanceledException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected TicketCantBeCanceledException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
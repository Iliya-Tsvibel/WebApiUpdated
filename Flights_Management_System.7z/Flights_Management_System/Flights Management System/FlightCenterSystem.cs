﻿using Flights_Management_System.POCO;
using FlightsManagementSystem.DAO;
using FlightsManagementSystem.Facade;
using FlightsManagementSystem.Login.InterfaceLogin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FlightsManagementSystem
{
    public class FlyingCenterSystem
    {
        static private FlyingCenterSystem _instance;
        static object key = new object();
        static public LoginService login_service = new LoginService();

        private FlyingCenterSystem()
        {
            Thread t = new Thread(UpdateFlightsAndTickets);
            t.Start();
        }

     
        static public FlyingCenterSystem GetInstance()
        {
            if (_instance == null)
            {
                lock (key)
                {
                    if (_instance == null)
                    {
                        _instance = new FlyingCenterSystem();
                    }
                }
            }
            return _instance;
        }

        public static UserAccessType /*bool*/ TryLogin(string userName, string password, out ILoginToken token, out FacadeBase facade)
        {
            if (login_service.TryCustomerLogin(userName, password, out LoginToken<Customer> customerToken))
            {
                token = customerToken;
                facade = new LoggedInAirlineFacade(); facade = new LoggedInCustomerFacade();
                //return true;
                return UserAccessType.Customer;
            }
            else if (login_service.TryAirlineLogin(userName, password, out LoginToken<AirlineCompany> airlineToken))
            {
                token = airlineToken;
                facade = new LoggedInAirlineFacade();
                //return true;
                return UserAccessType.Company;
            }
            else if (login_service.TryAdminLogin(userName, password, out LoginToken<Administrator> adminToken))
            {
                token = adminToken;
                facade = new LoggedInAdministratorFacade();
                //return true;
                return UserAccessType.Administrator;
            }
            throw new UserNotExistException("User not found. Ensure that you insert correct username.");
            token = null;
            facade = new AnonymousUserFacade();
            //return false;
            return UserAccessType.Anonymous;
        }
        void UpdateFlightsAndTickets()
        {
            Thread.Sleep(FlightCenterConfig.TIMEFORTHREADHISTORY);
            //Update Flights And Tickets.
            UpdateFlightsAndTickets();
        }
    }
}


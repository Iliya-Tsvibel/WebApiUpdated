﻿using System;
using FlightsManagementSystem;
using FlightsManagementSystem.Facade;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestFlightManagementSystem
{
    [TestClass]
    public class TestAdminUserFacade
    {
        //[TestInitialize]
        //public void testInit()
        //{
        //     TestCenter.CleanAllDataBase(out LoginToken<Administrator> adminToken, out LoggedInAdministratorFacade adminFacade);
        //}
       
        [TestMethod]
        public void CreatNewCustomer()
        {
            TestCenter.CleanAllDataBase(out LoginToken<Administrator> adminToken, out LoggedInAdministratorFacade adminFacade);
            Assert.AreEqual(adminFacade.GetAllCustomers(adminToken).Count, 0);
            Customer newCustomer = new Customer
            {
                FIRST_NAME = "Iliya",
                LAST_NAME = "Tsvibel",
                USER_NAME = "Iliya",
                PASSWORD = "1234",
                ADDRESS = "Rishon",
                PHONE_NO = "0546800559",
                CREDIT_CARD_NUMBER = "12345"
            };
            adminFacade.CreateNewCustomer(adminToken, newCustomer);
            Assert.AreEqual(adminFacade.GetAllCustomers(adminToken).Count, 1);
        }

        [TestMethod]
        public void UpdateCustomer()
        {
            TestCenter.CleanAllDataBase(out LoginToken<Administrator> adminToken, out LoggedInAdministratorFacade adminFacade);
            Assert.AreEqual(adminFacade.GetAllCustomers(adminToken).Count, 0);
            Customer updateCustomer = new Customer
            {
                FIRST_NAME = "Iliya",
                LAST_NAME = "Tsvibel",
                USER_NAME = "Iliya",
                PASSWORD = "1234",
                ADDRESS = "Rishon",
                PHONE_NO = "0546800559",
                CREDIT_CARD_NUMBER = "12345"
            };
            adminFacade.CreateNewCustomer(adminToken, updateCustomer);
            updateCustomer = adminFacade.GetCustomerByUserName(adminToken, updateCustomer.USER_NAME);
            updateCustomer.FIRST_NAME = "John";
            updateCustomer.LAST_NAME = "Lennon";
            updateCustomer.USER_NAME = "Iliya";
            updateCustomer.PASSWORD = "1234";
            updateCustomer.ADDRESS = "Liverpool";
            updateCustomer.PHONE_NO = "8989898";
            updateCustomer.CREDIT_CARD_NUMBER = "12345";
            adminFacade.UpdateCustomerDetails(adminToken, updateCustomer);
            Assert.AreEqual(adminFacade.GetCustomerByUserName(adminToken, updateCustomer.USER_NAME).FIRST_NAME, "John");
            Assert.AreEqual(adminFacade.GetCustomerByUserName(adminToken, updateCustomer.USER_NAME).LAST_NAME, "Lennon");
            Assert.AreEqual(adminFacade.GetCustomerByUserName(adminToken, updateCustomer.USER_NAME).PASSWORD, "1234");
            Assert.AreEqual(adminFacade.GetCustomerByUserName(adminToken, updateCustomer.USER_NAME).ADDRESS, "Liverpool");
            Assert.AreEqual(adminFacade.GetCustomerByUserName(adminToken, updateCustomer.USER_NAME).PHONE_NO, "8989898");
            Assert.AreEqual(adminFacade.GetCustomerByUserName(adminToken, updateCustomer.USER_NAME).CREDIT_CARD_NUMBER, "12345");
        }

        [TestMethod]
        public void RemoveCustomer()
        {
            TestCenter.CleanAllDataBase(out LoginToken<Administrator> adminToken, out LoggedInAdministratorFacade adminFacade);
            Assert.AreEqual(adminFacade.GetAllCustomers(adminToken).Count, 0);
            Customer deleteCustomer = new Customer
            {
                FIRST_NAME = "Iliya",
                LAST_NAME = "Tsvibel",
                USER_NAME = "Iliya",
                PASSWORD = "1234",
                ADDRESS = "Rishon",
                PHONE_NO = "0546800559",
                CREDIT_CARD_NUMBER = "12345"
            };
            adminFacade.CreateNewCustomer(adminToken, deleteCustomer);
            Assert.AreEqual(adminFacade.GetAllCustomers(adminToken).Count, 1);
            adminFacade.RemoveCustomer(adminToken, deleteCustomer);
            Assert.AreEqual(adminFacade.GetAllCustomers(adminToken).Count, 0);
        }

        [TestMethod]
        public void CreatNewAirline()
        {
            TestCenter.CleanAllDataBase(out LoginToken<Administrator> adminToken, out LoggedInAdministratorFacade adminFacade);
            Assert.AreEqual(adminFacade.GetAllAirlineCompanies().Count, 0);
            Country newCountry = new Country { COUNTRY_NAME = FlightCenterConfig.COUNTRY_NAME };
            adminFacade.CreateNewCountry(adminToken, newCountry);
            AirlineCompany newAirline = new AirlineCompany
            {
                AIRLINE_NAME = FlightCenterConfig.AIRLINE_NAME,
                USER_NAME = FlightCenterConfig.AIRLINE_USER_NAME,
                COUNTRY_CODE = adminFacade.GetCountryByName(adminToken, FlightCenterConfig.COUNTRY_NAME).ID,
                PASSWORD = FlightCenterConfig.AIRLINE_PASSWORD

            };
            adminFacade.CreateNewAirline(adminToken, newAirline);
            Assert.AreEqual(adminFacade.GetAllAirlineCompanies().Count, 1);
        }

        [TestMethod]
        public void UpdateAirline()
        {
            TestCenter.CleanAllDataBase(out LoginToken<Administrator> adminToken, out LoggedInAdministratorFacade adminFacade);
            Assert.AreEqual(adminFacade.GetAllAirlineCompanies().Count, 0);
            Country newCountry = new Country { COUNTRY_NAME = FlightCenterConfig.COUNTRY_NAME };
            adminFacade.CreateNewCountry(adminToken, newCountry);
            AirlineCompany updateAirline = new AirlineCompany
            {
                AIRLINE_NAME = FlightCenterConfig.AIRLINE_NAME,
                USER_NAME = FlightCenterConfig.AIRLINE_USER_NAME,
                COUNTRY_CODE = adminFacade.GetCountryByName(adminToken, FlightCenterConfig.COUNTRY_NAME).ID,
                PASSWORD = FlightCenterConfig.AIRLINE_PASSWORD
            };
            adminFacade.CreateNewAirline(adminToken, updateAirline);
            updateAirline = adminFacade.GetAirlineByName(adminToken, updateAirline.AIRLINE_NAME);
            updateAirline.AIRLINE_NAME = "Hitler's kaputt!";
            updateAirline.USER_NAME = "Gebbels";
            updateAirline.COUNTRY_CODE = adminFacade.GetCountryByName(adminToken, FlightCenterConfig.COUNTRY_NAME).ID;
            updateAirline.PASSWORD = "1234";
            adminFacade.UpdateAirlineDetails(adminToken, updateAirline);
            Assert.AreEqual(updateAirline.AIRLINE_NAME, "Hitler's kaputt!");
            Assert.AreEqual(updateAirline.USER_NAME, "Gebbels");
            Assert.AreEqual(updateAirline.PASSWORD, "1234");
        }

        [TestMethod]
        public void RemoveAirline()
        {
            TestCenter.CleanAllDataBase(out LoginToken<Administrator> adminToken, out LoggedInAdministratorFacade adminFacade);
            Assert.AreEqual(adminFacade.GetAllAirlineCompanies().Count, 0);
            Country newCountry = new Country { COUNTRY_NAME = FlightCenterConfig.COUNTRY_NAME };
            adminFacade.CreateNewCountry(adminToken, newCountry);
            AirlineCompany deleteAirline = new AirlineCompany
            {
                AIRLINE_NAME = FlightCenterConfig.AIRLINE_NAME,
                USER_NAME = FlightCenterConfig.AIRLINE_USER_NAME,
                COUNTRY_CODE = adminFacade.GetCountryByName(adminToken, FlightCenterConfig.COUNTRY_NAME).ID,
                PASSWORD = FlightCenterConfig.AIRLINE_PASSWORD
            };
            adminFacade.CreateNewAirline(adminToken, deleteAirline);
            Assert.AreEqual(adminFacade.GetAllAirlineCompanies().Count, 1);
            adminFacade.RemoveAirline(adminToken, deleteAirline);
            Assert.AreEqual(adminFacade.GetAllAirlineCompanies().Count, 0);
        }
    }
}

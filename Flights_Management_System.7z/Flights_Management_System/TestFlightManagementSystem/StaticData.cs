﻿using FlightsManagementSystem;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestFlightManagementSystem
{
    public class StaticData
    {
      
    }
}

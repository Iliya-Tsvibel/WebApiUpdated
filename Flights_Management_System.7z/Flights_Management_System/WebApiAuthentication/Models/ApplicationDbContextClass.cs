﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace WebApiAuthentication.Models
{
    public class ApplicationDbContextClass:DbContext

    {
        public ApplicationDbContextClass(DbContextOptions<ApplicationDbContextClass> options):base(options)
        {

        }
        public DbSet<EmpTableClass> AIRLINECOMPANY_ID { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightsManagementSystem.DAO
{
    public class CustomerDAOMSSQL : ICustomerDAO
    {
        public long Add(Customer t)
        {
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("CREATE_NEW_CUSTOMER", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@FIRST_NAME", t.FIRST_NAME));
                    cmd.Parameters.Add(new SqlParameter("@LAST_NAME", t.LAST_NAME));
                    cmd.Parameters.Add(new SqlParameter("@USER_NAME", t.USER_NAME));
                    cmd.Parameters.Add(new SqlParameter("@PASSWORD", t.PASSWORD));
                    cmd.Parameters.Add(new SqlParameter("@ADDRESS", t.ADDRESS));
                    cmd.Parameters.Add(new SqlParameter("@PHONE_NO", t.PHONE_NO));
                    cmd.Parameters.Add(new SqlParameter("@CREDIT_CARD_NUMBER", t.CREDIT_CARD_NUMBER));
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                    return t.ID = (long)cmd.ExecuteScalar();
                }
            }
        }
        public void Update(Customer t)
        {
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("UPDATE_CUSTOMER", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@FIRST_NAME", t.FIRST_NAME));
                    cmd.Parameters.Add(new SqlParameter("@LAST_NAME", t.LAST_NAME));
                    cmd.Parameters.Add(new SqlParameter("@USER_NAME", t.USER_NAME));
                    cmd.Parameters.Add(new SqlParameter("@PASSWORD", t.PASSWORD));
                    cmd.Parameters.Add(new SqlParameter("@ADDRESS", t.ADDRESS));
                    cmd.Parameters.Add(new SqlParameter("@PHONE_NO", t.PHONE_NO));
                    cmd.Parameters.Add(new SqlParameter("@CREDIT_CARD_NUMBER", t.CREDIT_CARD_NUMBER));
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                    cmd.Connection.Close();
                }
            }
        }
        public Customer Get(int id)
        {
            Customer CustomerById = new Customer();

            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("GET_CUSTOMER_BY_ID", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@ID", id));
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            CustomerById.ID = id;
                            CustomerById.FIRST_NAME = (string)reader["FIRST_NAME"];
                            CustomerById.LAST_NAME = (string)reader["LAST_NAME"];
                            CustomerById.USER_NAME = (string)reader["USER_NAME"];
                            CustomerById.PASSWORD = (string)reader["PASSWORD"];
                            CustomerById.ADDRESS = (string)reader["ADDRESS"];
                            CustomerById.PHONE_NO = (string)reader["PHONE_NO"];
                            CustomerById.CREDIT_CARD_NUMBER = (string)reader["CREDIT_CARD_NUMBER"];
                        }
                    }
                    cmd.Connection.Close();
                }

            }
            return CustomerById;
        }
        public Customer GetMinID()
        {
            Customer CustomerMinId = new Customer();

            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("GET_MIN_CUSTOMER_ID", sqlConnection))
                {
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            CustomerMinId.ID = (long)reader["ID"];
                        }
                    }
                    cmd.Connection.Close();
                }

            }
            return CustomerMinId;
        }
        public long CountCustomers()
        {
            //Customer CountCustomers = new Customer();
            long output = 0;
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("CUSTOMERS_AMOUNT", sqlConnection))
                {
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                  
                    output = (long)cmd.ExecuteScalar();
                    
                    cmd.Connection.Close();
                }
                
            }
            return output;
        }
       
        public IList<Customer> GetAll()
        {
            List<Customer> AllCustomers = new List<Customer>();

            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT_ALL_CUSTOMERS", sqlConnection))
                {
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Customer Customer = new Customer();
                            Customer.ID = (long)reader["ID"];
                            Customer.FIRST_NAME = (string)reader["FIRST_NAME"];
                            Customer.LAST_NAME = (string)reader["LAST_NAME"];
                            Customer.USER_NAME = (string)reader["USER_NAME"];
                            Customer.PASSWORD = (string)reader["PASSWORD"];
                            Customer.ADDRESS = (string)reader["ADDRESS"];
                            Customer.PHONE_NO = (string)reader["PHONE_NO"];
                            Customer.CREDIT_CARD_NUMBER = (string)reader["CREDIT_CARD_NUMBER"];

                            AllCustomers.Add(Customer);
                        }
                    }
                    cmd.Connection.Close();
                }
            }
            return AllCustomers;
        }
        public Customer GetCustomerByUserame(string name)
        {
            Customer userName = null;
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                SqlCommand FindCustomerByUsername = new SqlCommand("GET_CUSTOMER_BY_USER_NAME", sqlConnection);
                FindCustomerByUsername.Parameters.Add(new SqlParameter("@USER_NAME", name));
                FindCustomerByUsername.Connection.Open();
                FindCustomerByUsername.CommandType = CommandType.StoredProcedure;
                sqlConnection.InfoMessage += delegate (object sender, SqlInfoMessageEventArgs e)
                {
                    Console.WriteLine(e.Message);
                };

                SqlDataReader sqlDataReader = FindCustomerByUsername.ExecuteReader(CommandBehavior.Default);

                while (sqlDataReader.Read() == true)
                {

                    userName.FIRST_NAME = (string)sqlDataReader["FIRST_NAME"];
                    userName.LAST_NAME = (string)sqlDataReader["LAST_NAME"];
                    userName.PASSWORD = (string)sqlDataReader["PASSWORD"];
                    userName.USER_NAME = (string)sqlDataReader["USER_NAME"];
                    userName.PHONE_NO = (string)sqlDataReader["PHONE_NO"];
                    userName.CREDIT_CARD_NUMBER = (string)sqlDataReader["CREDIT_CARD_NUMBER"];
                    userName.ADDRESS = (string)sqlDataReader["ADDRESS"];
                    userName.ID = (long)sqlDataReader["ID"];
                    Console.WriteLine(" ");
                }

                FindCustomerByUsername.Connection.Close();
            }
            return userName;
        }
        public void Remove(Customer t)
        {
            Customer userName = new Customer();
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                SqlCommand FindCustomerByUsername = new SqlCommand("GET_CUSTOMER_BY_USER_NAME", sqlConnection);
                FindCustomerByUsername.Parameters.Add(new SqlParameter("@USER_NAME", t.USER_NAME));
                FindCustomerByUsername.Connection.Open();
                FindCustomerByUsername.CommandType = CommandType.StoredProcedure;
                sqlConnection.InfoMessage += delegate (object sender, SqlInfoMessageEventArgs e)
                {
                    Console.WriteLine(e.Message);
                };

                SqlDataReader sqlDataReader = FindCustomerByUsername.ExecuteReader(CommandBehavior.Default);

                while (sqlDataReader.Read() == true)
                {
                    userName.ID = (long)sqlDataReader["ID"];
                    Console.WriteLine(" ");
                }
                FindCustomerByUsername.Connection.Close();
                
                using (SqlCommand cmd = new SqlCommand("DELETE_ALL_CUSTOMER_TICKETS", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@CUSTOMER_ID", userName.ID));
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                    cmd.Connection.Close();
                }
                using (SqlCommand cmd = new SqlCommand("REMOVE_CUSTOMER_DETAILS", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@USER_NAME", t.USER_NAME));
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                    cmd.Connection.Close();
                }
            }
        }
    
        public void ChangePassword(Customer change_password)
        {
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("CHANGE_CUSTOMER_PASSWORD", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@AIRLINE_NAME", change_password.USER_NAME));
                    cmd.Parameters.Add(new SqlParameter("@PASSWORD", change_password.PASSWORD));

                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                }
            }
        }
       
    }
}

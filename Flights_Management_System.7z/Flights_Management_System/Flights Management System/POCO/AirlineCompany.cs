﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightsManagementSystem
{
    // This is the POCO Class
    public class AirlineCompany : IPoco, IUser
    {
        private string pASSWORD1;

        public long ID { get; set; }
        public string AIRLINE_NAME { get; set; }
        public string USER_NAME { get; set; }
        public string PASSWORD { get; set; }
        public long COUNTRY_CODE { get; set; }



        // Constructor without parameters
        public AirlineCompany()
        {

        }

        // Constructor with parameters
        public AirlineCompany(long iD, string aIRLINE_NAME, string uSER_NAME, string pASSWORD, long cOUNTRY_CODE)
        {
            ID = iD;
            AIRLINE_NAME = aIRLINE_NAME;
            USER_NAME = uSER_NAME;
            PASSWORD = pASSWORD;
            COUNTRY_CODE = cOUNTRY_CODE;
        }
        // Constructor for test without ID parameter
        public AirlineCompany(string aIRLINE_NAME, string uSER_NAME, string pASSWORD, long cOUNTRY_CODE)
        {
            AIRLINE_NAME = aIRLINE_NAME;
            USER_NAME = uSER_NAME;
            PASSWORD = pASSWORD;
            COUNTRY_CODE = cOUNTRY_CODE;
        }

        // Constructor with login parameters
        public AirlineCompany(string uSER_NAME, string pASSWORD)
        {

            USER_NAME = uSER_NAME;
            PASSWORD = pASSWORD;

        }

        public AirlineCompany(string uSER_NAME, string pASSWORD, long cOUNTRY_CODE, string pASSWORD1) : this(uSER_NAME, pASSWORD)
        {
            COUNTRY_CODE = cOUNTRY_CODE;
            this.pASSWORD1 = pASSWORD1;
        }

        // Equals check
        // This Function Override The Real Operator == and Check If This ID And Other ID Are Equals
        public static bool operator ==(AirlineCompany thisCompany, AirlineCompany otherCompany)
        {

            if (ReferenceEquals(thisCompany, null) && ReferenceEquals(otherCompany, null))
                return true;
            if (ReferenceEquals(thisCompany, null) || ReferenceEquals(otherCompany, null))
                return false;

            return (thisCompany.ID == otherCompany.ID);
        }

        // This Function Override The Real Operator != and Check If This ID And Other ID are not Equals
        public static bool operator !=(AirlineCompany thisCompany, AirlineCompany otherCompany)
        {
            return !(thisCompany == otherCompany);
        }

        // This Function Override The Real Function Equals And Compair Between This ID and Other ID
        public override bool Equals(object obj)
        {

            if (obj == null)
                return false;
            AirlineCompany a = obj as AirlineCompany;
            if (a == null)
                return false;
            return ID == a.ID;
        }


        //Hash Code override

        public override int GetHashCode()
        {
            return Convert.ToInt32(this.ID);
        }




    }
}

﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace FlightsManagementSystem.DAO
{
    public class FlightDAOMSSQL : IFlightDAO
    {
        public long Add(Flight f)
        {
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("CREATE_NEW_FLIGHT", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@AIRLINECOMPANY_ID", f.AIRLINECOMPANY_ID));
                    cmd.Parameters.Add(new SqlParameter("@ORIGIN_COUNTRY_CODE", f.ORIGIN_COUNTRY_CODE));
                    cmd.Parameters.Add(new SqlParameter("@DESTINATION_COUNTRY_CODE", f.DESTINATION_COUNTRY_CODE));
                    cmd.Parameters.Add(new SqlParameter("@DEPARTURE_TIME", f.DEPARTURE_TIME));
                    cmd.Parameters.Add(new SqlParameter("@LANDING_TIME", f.ORIGIN_COUNTRY_CODE));
                    cmd.Parameters.Add(new SqlParameter("@REMAINING_TICKETS", f.REMAINING_TICKETS));
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                    return f.ID = (long)cmd.ExecuteScalar();
                }
            }
        }
        public Flight Get(int id)
        {
            Flight FlightById = new Flight();
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("GET_FLIGHT_BY_ID", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@ID", id));
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            FlightById.ID = id;
                            FlightById.AIRLINECOMPANY_ID = (long)reader["AIRLINECOMPANY_ID"];
                            FlightById.ORIGIN_COUNTRY_CODE = (long)reader["ORIGIN_COUNTRY_CODE"];
                            FlightById.DESTINATION_COUNTRY_CODE = (long)reader["DESTINATION_COUNTRY_CODE"];
                            FlightById.DEPARTURE_TIME = (DateTime)reader["DEPARTURE_TIME"];
                            FlightById.LANDING_TIME = (DateTime)reader["LANDING_TIME"];
                            FlightById.REMAINING_TICKETS = (int)reader["REMAINING_TICKETS"];
                        }
                    }
                }

            }
            return FlightById;
        }
        public IList<Flight> GetAll()
        {
            List<Flight> AllFlights = new List<Flight>();
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT_ALL_FLIGHT", sqlConnection))
                {
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    using (SqlDataReader read = cmd.ExecuteReader())
                    {
                        while (read.Read())
                        {
                            Flight Flight = new Flight();
                            Flight.ID = (long)read["ID"];
                            Flight.AIRLINECOMPANY_ID = (long)read["AIRLINECOMPANY_ID"];
                            Flight.ORIGIN_COUNTRY_CODE = (long)read["ORIGIN_COUNTRY_CODE"];
                            Flight.DESTINATION_COUNTRY_CODE = (long)read["DESTINATION_COUNTRY_CODE"];
                            Flight.DEPARTURE_TIME = (DateTime)read["DEPARTURE_TIME"];
                            Flight.LANDING_TIME = (DateTime)read["LANDING_TIME"];
                            Flight.REMAINING_TICKETS = (int)read["REMAINING_TICKETS"];

                            AllFlights.Add(Flight);
                        }
                    }
                }
            }
            return AllFlights;
        }

        public Dictionary<Flight, int> GetAllFlightsVacancy()
        {
            Dictionary<Flight, int> FlightsVacancy = new Dictionary<Flight, int>();
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("GET_VACANCY_FLIGHTS", sqlConnection))
                {
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    using (SqlDataReader read = cmd.ExecuteReader())
                    {
                        while (read.Read())
                        {
                            Flight Flight = new Flight();
                            Flight.ID = (long)read["ID"];
                            Flight.AIRLINECOMPANY_ID = (long)read["AIRLINECOMPANY_ID"];
                            Flight.ORIGIN_COUNTRY_CODE = (long)read["ORIGIN_COUNTRY_CODE"];
                            Flight.DESTINATION_COUNTRY_CODE = (long)read["DESTINATION_COUNTRY_CODE"];
                            Flight.DEPARTURE_TIME = (DateTime)read["DEPARTURE_TIME"];
                            Flight.LANDING_TIME = (DateTime)read["LANDING_TIME"];
                            Flight.REMAINING_TICKETS = (int)read["REMAINING_TICKETS"];
                            FlightsVacancy.Add(Flight, Flight.REMAINING_TICKETS);

                        }
                    }
                }
            }
            return FlightsVacancy;
        }

        public Flight GetFlightById(long id)
        {
            Flight flight = new Flight();
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                sqlConnection.Open();
                SqlCommand FindFlightById = new SqlCommand("GET_FLIGHT_BY_ID", sqlConnection);
                FindFlightById.Parameters.Add(new SqlParameter("@ID", id));
                FindFlightById.CommandType = CommandType.StoredProcedure;

                sqlConnection.InfoMessage += delegate (object sender, SqlInfoMessageEventArgs e)
                {
                    Console.WriteLine(e.Message);
                };

                SqlDataReader sqlDataReader = FindFlightById.ExecuteReader(CommandBehavior.Default);

                while (sqlDataReader.Read() == true)
                {


                    flight.ID = (long)sqlDataReader["ID"];
                    flight.AIRLINECOMPANY_ID = (long)sqlDataReader["AIRLINECOMPANY_ID"];
                    flight.ORIGIN_COUNTRY_CODE = (long)sqlDataReader["ORIGIN_COUNTRY_CODE"];
                    flight.DESTINATION_COUNTRY_CODE = (long)sqlDataReader["DESTINATION_COUNTRY_CODE"];
                    flight.DEPARTURE_TIME = (DateTime)sqlDataReader["DEPARTURE_TIME"];
                    flight.LANDING_TIME = (DateTime)sqlDataReader["LANDING_TIME"];
                    flight.REMAINING_TICKETS = (int)sqlDataReader["REMAINING_TICKETS"];

                }

                FindFlightById.Connection.Close();
            }
            return flight;
        }

        public Flight GetFlightByAirline(long airlineID)
        {
            Flight flight = new Flight();
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                sqlConnection.Open();
                SqlCommand FindFlightByAirline = new SqlCommand("GET_FLIGHT_BY_AIRLINE", sqlConnection);
                FindFlightByAirline.Parameters.Add(new SqlParameter("@AIRLINECOMPANY_ID", airlineID));
                FindFlightByAirline.CommandType = CommandType.StoredProcedure;

                sqlConnection.InfoMessage += delegate (object sender, SqlInfoMessageEventArgs e)
                {
                    Console.WriteLine(e.Message);
                };

                SqlDataReader sqlDataReader = FindFlightByAirline.ExecuteReader(CommandBehavior.Default);

                while (sqlDataReader.Read() == true)
                {


                    flight.ID = (long)sqlDataReader["ID"];
                    flight.AIRLINECOMPANY_ID = (long)sqlDataReader["AIRLINECOMPANY_ID"];
                    flight.ORIGIN_COUNTRY_CODE = (long)sqlDataReader["ORIGIN_COUNTRY_CODE"];
                    flight.DESTINATION_COUNTRY_CODE = (long)sqlDataReader["DESTINATION_COUNTRY_CODE"];
                    flight.DEPARTURE_TIME = (DateTime)sqlDataReader["DEPARTURE_TIME"];
                    flight.LANDING_TIME = (DateTime)sqlDataReader["LANDING_TIME"];
                    flight.REMAINING_TICKETS = (int)sqlDataReader["REMAINING_TICKETS"];

                }

                FindFlightByAirline.Connection.Close();
            }
            return flight;
        }
        public IList<Flight> GetFlightsByCustomer(Customer customer)
        {
            List<Flight> flight = new List<Flight>();
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                sqlConnection.Open();
                SqlCommand FindTicketsByUser = new SqlCommand("GET_ALL_MY_FLIGHTS", sqlConnection);
                FindTicketsByUser.Parameters.Add(new SqlParameter("@ID", customer.ID));
                FindTicketsByUser.CommandType = CommandType.StoredProcedure;

                sqlConnection.InfoMessage += delegate (object sender, SqlInfoMessageEventArgs e)
                {
                    Console.WriteLine(e.Message);
                };

                SqlDataReader sqlDataReader = FindTicketsByUser.ExecuteReader(CommandBehavior.Default);

                while (sqlDataReader.Read() == true)
                {
                    flight.Add(new Flight
                    {
                        ID = (long)sqlDataReader["ID"],
                        AIRLINECOMPANY_ID = (long)sqlDataReader["AIRLINECOMPANY_ID"],
                        ORIGIN_COUNTRY_CODE = (long)sqlDataReader["ORIGIN_COUNTRY_CODE"],
                        DESTINATION_COUNTRY_CODE = (long)sqlDataReader["DESTINATION_COUNTRY_CODE"],
                        DEPARTURE_TIME = (DateTime)sqlDataReader["DEPARTURE_TIME"],
                        LANDING_TIME = (DateTime)sqlDataReader["LANDING_TIME"],
                        REMAINING_TICKETS = (int)sqlDataReader["REMAINING_TICKETS"]
                    });
                }

                FindTicketsByUser.Connection.Close();
            }
            return flight;
        }
        public IList<Flight> GetFlightsByDepatrureDate(DateTime departureDate)
        {
            List<Flight> flight = new List<Flight>();
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                SqlCommand FindFlightByDepartureDate = new SqlCommand("GET_FLIGHT_BY_DEPARTURE_TIME", sqlConnection);
                FindFlightByDepartureDate.Parameters.Add(new SqlParameter("@DEPARTURE_TIME", departureDate));
                FindFlightByDepartureDate.Connection.Open();
                FindFlightByDepartureDate.CommandType = CommandType.StoredProcedure;
                sqlConnection.InfoMessage += delegate (object sender, SqlInfoMessageEventArgs e)
                {
                    Console.WriteLine(e.Message);
                };

                SqlDataReader sqlDataReader = FindFlightByDepartureDate.ExecuteReader(CommandBehavior.Default);

                while (sqlDataReader.Read() == true)
                {

                    flight.Add(new Flight
                    {
                        ID = (long)sqlDataReader["ID"],
                        AIRLINECOMPANY_ID = (long)sqlDataReader["AIRLINECOMPANY_ID"],
                        ORIGIN_COUNTRY_CODE = (long)sqlDataReader["ORIGIN_COUNTRY_CODE"],
                        DESTINATION_COUNTRY_CODE = (long)sqlDataReader["DESTINATION_COUNTRY_CODE"],
                        DEPARTURE_TIME = (DateTime)sqlDataReader["DEPARTURE_TIME"],
                        LANDING_TIME = (DateTime)sqlDataReader["LANDING_TIME"],
                        REMAINING_TICKETS = (int)sqlDataReader["REMAINING_TICKETS"]
                    });
                }

                FindFlightByDepartureDate.Connection.Close();
            }
            return flight;
        }
        public IList<Flight> GetFlightsByDestinationCountry(long countryCode)
        {
            List<Flight> flight = new List<Flight>();
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                SqlCommand FindDestinationCountryById = new SqlCommand("GET_FLIGHT_BY_DESTINATION_COUNTRY", sqlConnection);
                FindDestinationCountryById.Parameters.Add(new SqlParameter("@DESTINATION_COUNTRY_CODE", countryCode));
                FindDestinationCountryById.Connection.Open();
                FindDestinationCountryById.CommandType = CommandType.StoredProcedure;
                sqlConnection.InfoMessage += delegate (object sender, SqlInfoMessageEventArgs e)
                {
                    Console.WriteLine(e.Message);
                };

                SqlDataReader sqlDataReader = FindDestinationCountryById.ExecuteReader(CommandBehavior.Default);

                while (sqlDataReader.Read() == true)
                {

                    flight.Add(new Flight
                    {
                        ID = (long)sqlDataReader["ID"],
                        AIRLINECOMPANY_ID = (long)sqlDataReader["AIRLINECOMPANY_ID"],
                        ORIGIN_COUNTRY_CODE = (long)sqlDataReader["ORIGIN_COUNTRY_CODE"],
                        DESTINATION_COUNTRY_CODE = (long)sqlDataReader["DESTINATION_COUNTRY_CODE"],
                        DEPARTURE_TIME = (DateTime)sqlDataReader["DEPARTURE_TIME"],
                        LANDING_TIME = (DateTime)sqlDataReader["LANDING_TIME"],
                        REMAINING_TICKETS = (int)sqlDataReader["REMAINING_TICKETS"]
                    });
                }

                FindDestinationCountryById.Connection.Close();
            }
            return flight;
        }

        public IList<Flight> GetFlightsByLandingDate(DateTime landingDate)
        {
            List<Flight> flight = new List<Flight>();
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                SqlCommand FindFlightByLandingDate = new SqlCommand("GET_FLIGHT_BY_LANDING_TIME", sqlConnection);
                FindFlightByLandingDate.Parameters.Add(new SqlParameter("@LANDING_TIME", landingDate));
                FindFlightByLandingDate.Connection.Open();
                FindFlightByLandingDate.CommandType = CommandType.StoredProcedure;
                sqlConnection.InfoMessage += delegate (object sender, SqlInfoMessageEventArgs e)
                {
                    Console.WriteLine(e.Message);
                };

                SqlDataReader sqlDataReader = FindFlightByLandingDate.ExecuteReader(CommandBehavior.Default);

                while (sqlDataReader.Read() == true)
                {

                    flight.Add(new Flight
                    {
                        ID = (long)sqlDataReader["ID"],
                        AIRLINECOMPANY_ID = (long)sqlDataReader["AIRLINECOMPANY_ID"],
                        ORIGIN_COUNTRY_CODE = (long)sqlDataReader["ORIGIN_COUNTRY_CODE"],
                        DESTINATION_COUNTRY_CODE = (long)sqlDataReader["DESTINATION_COUNTRY_CODE"],
                        DEPARTURE_TIME = (DateTime)sqlDataReader["DEPARTURE_TIME"],
                        LANDING_TIME = (DateTime)sqlDataReader["LANDING_TIME"],
                        REMAINING_TICKETS = (int)sqlDataReader["REMAINING_TICKETS"]
                    });
                }

                FindFlightByLandingDate.Connection.Close();
            }
            return flight;
        }
        public IList<Flight> GetFlightsByOriginCountry(long countryCode)
        {
            List<Flight> flight = new List<Flight>();
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                SqlCommand FindOriginCountryById = new SqlCommand("GET_FLIGHT_BY_ORIGIN_COUNTRY", sqlConnection);
                FindOriginCountryById.Parameters.Add(new SqlParameter("@ORIGIN_COUNTRY_CODE", countryCode));
                FindOriginCountryById.Connection.Open();
                FindOriginCountryById.CommandType = CommandType.StoredProcedure;
                sqlConnection.InfoMessage += delegate (object sender, SqlInfoMessageEventArgs e)
                {
                    Console.WriteLine(e.Message);
                };

                SqlDataReader sqlDataReader = FindOriginCountryById.ExecuteReader(CommandBehavior.Default);

                while (sqlDataReader.Read() == true)
                {

                    flight.Add(new Flight
                    {
                        ID = (long)sqlDataReader["ID"],
                        AIRLINECOMPANY_ID = (long)sqlDataReader["AIRLINECOMPANY_ID"],
                        ORIGIN_COUNTRY_CODE = (long)sqlDataReader["ORIGIN_COUNTRY_CODE"],
                        DESTINATION_COUNTRY_CODE = (long)sqlDataReader["DESTINATION_COUNTRY_CODE"],
                        DEPARTURE_TIME = (DateTime)sqlDataReader["DEPARTURE_TIME"],
                        LANDING_TIME = (DateTime)sqlDataReader["LANDING_TIME"],
                        REMAINING_TICKETS = (int)sqlDataReader["REMAINING_TICKETS"]
                    });
                }

                FindOriginCountryById.Connection.Close();
            }
            return flight;
        }

        public Flight GetMinFlightID()
        {
            Flight FlightMinId = new Flight();

            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("GET_MIN_FLIGHT_ID", sqlConnection))
                {
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            FlightMinId.ID = (long)reader["ID"];
                        }
                    }
                    cmd.Connection.Close();
                }

            }
            return FlightMinId;
        }

        public void Remove(Flight f)
        {
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("DELTE_TICKETS_BY_FLIGHT", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@FLIGHT_ID", f.ID));
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                }
                using (SqlCommand cmd = new SqlCommand("DELETE_FLIGHTS", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@ID", f.ID));
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void RemoveFlightByAirline(Flight flight)
        {
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("REMOVE_FLIGHTS_BY_AIRLINE", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@AIRLINECOMPANY_ID", flight.AIRLINECOMPANY_ID));
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void Update(Flight f)
        {
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("UPDATE_FLIGHTS_DETAILS", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@ID", f.ID));
                    cmd.Parameters.Add(new SqlParameter("@AIRLINECOMPANY_ID", f.AIRLINECOMPANY_ID));
                    cmd.Parameters.Add(new SqlParameter("@ORIGIN_COUNTRY_CODE", f.ORIGIN_COUNTRY_CODE));
                    cmd.Parameters.Add(new SqlParameter("@DESTINATION_COUNTRY_CODE", f.DESTINATION_COUNTRY_CODE));
                    cmd.Parameters.Add(new SqlParameter("@DEPARTUE_TIME", f.DEPARTURE_TIME));
                    cmd.Parameters.Add(new SqlParameter("@LANDING_TIME", f.LANDING_TIME));
                    cmd.Parameters.Add(new SqlParameter("@REMAINING_TICKETS", f.REMAINING_TICKETS));

                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                }
            }
        }


        public bool DoesFlightExistByFlightID(long fLIGHT_ID)

        {
            int result;
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {

                SqlCommand FindFlightByID = new SqlCommand("GET_FLIGHT_BY_ID", sqlConnection);

                FindFlightByID.Parameters.Add(new SqlParameter("@ID", fLIGHT_ID));

                FindFlightByID.Connection.Open();

                FindFlightByID.CommandType = CommandType.StoredProcedure;

                SqlDataReader sqlDataReader = FindFlightByID.ExecuteReader(CommandBehavior.Default);



                if (sqlDataReader.Read() == true)

                {

                    result = 1;

                }

                else

                    result = 0;


                FindFlightByID.Connection.Close();


                if (result == 1)

                {

                    return true;

                }

                else

                    return false;
            }


        }

        public bool CheckInventoryByFlightID(long fLIGHT_ID)

        {
            int result;
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {

                SqlCommand FindVacancyFlight = new SqlCommand("CHECK_INVENTORY", sqlConnection);

                FindVacancyFlight.Parameters.Add(new SqlParameter("@ID", fLIGHT_ID));

                FindVacancyFlight.Connection.Open();

                FindVacancyFlight.CommandType = CommandType.StoredProcedure;

                SqlDataReader sqlDataReader = FindVacancyFlight.ExecuteReader(CommandBehavior.Default);



                if (sqlDataReader.Read() == true)

                {

                    result = 1;

                }

                else

                    result = 0;


                FindVacancyFlight.Connection.Close();


                if (result == 1)

                {

                    return true;

                }

                else

                    return false;
            }
        }
        public void UpdateInventoryMinus(long flightId)
        {
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("UPDATE_INVENTORY_MINUS", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@FLIGHT_ID", flightId));
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void UpdateInventoryPlus(long flightId)
        {
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfig.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("UPDATE_INVENTORY_PLUS", sqlConnection))
                {
                    cmd.Parameters.Add(new SqlParameter("@FLIGHT_ID", flightId));
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}

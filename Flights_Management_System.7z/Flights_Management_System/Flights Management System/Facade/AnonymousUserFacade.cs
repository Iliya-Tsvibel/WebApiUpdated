﻿using FlightsManagementSystem.DAO;
using FlightsManagementSystem.DAO.InterfaceDAO;
using FlightsManagementSystem.Facade.InterfaceFacade;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FlightsManagementSystem.Facade
{
     
    // Facade with basic functions without login
    public class AnonymousUserFacade : FacadeBase, IAnonymousUserFacade
    {

        private new IAirlineDAO _airlineDAO = new AirlineDAOMSSQL();
        private new IAdminDAO _adminDAO = new AdminDAOMSSQL();
        private new ICustomerDAO _customerDAO = new CustomerDAOMSSQL();
        private new ICountryDAO _countryDAO = new CountryDAOMSSQL();
        private new ITicketDAO _ticketDAO = new TicketDAOMSSQL();
        private new IFlightDAO _flightDAO = new FlightDAOMSSQL();
        public AnonymousUserFacade()
        {

        }
        public IList<Flight> GetAllFlights()
        {
            return _flightDAO.GetAll();
        }
        public IList<AirlineCompany> GetAllAirlineCompanies()
        {
            return _airlineDAO.GetAll();
        }
        public Dictionary<Flight, int> GetAllFlightsVacancy()
        {
            return _flightDAO.GetAllFlightsVacancy();
        }

        public Flight GetFlightById(int id)
        {
            //return flights.Find((f) => { return f.ID == id; });
            return _flightDAO.GetFlightById(id);
        }
        public IList<Flight> GetFlightsByOriginCountry(long countryCode)
        {
            return _flightDAO.GetFlightsByOriginCountry(countryCode);
        }
        public IList<Flight> GetFlightsByDestinationCountry(long countryCode)
        {
            return _flightDAO.GetFlightsByDestinationCountry(countryCode);
        }
        public IList<Flight> GetFlightsByDepatrureDate(DateTime departureDate)
        {
            return _flightDAO.GetFlightsByDepatrureDate(departureDate);
        }
        public IList<Flight> GetFlightsByLandingDate(DateTime landingDate)
        {
            return _flightDAO.GetFlightsByLandingDate(landingDate);
        }
        public Country GetCountryByName(string name)
        {
            return _countryDAO.GetByName(name);
        }

        public IList<Flight> GetFlightsByOriginCountry(int countryCode)
        {
            throw new NotImplementedException();
        }

        public IList<Flight> GetFlightsByDestinationCountry(int countryCode)
        {
            throw new NotImplementedException();
        }

        public long CreateNewCustomer(Customer customer)
        {

              return customer.ID = _customerDAO.Add(customer);
            
        }
    }
}

﻿using System;
using FlightsManagementSystem;
using FlightsManagementSystem.Facade;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestFlightManagementSystem
{
    [TestClass]
    public class TestCustomerUserFacade
    {
        //[TestMethod]
        //public void GetAllMyFlight()
        //{
        //    TestCenter.CleanAllDataBase(out LoginToken<Administrator> adminToken, out LoggedInAdministratorFacade adminFacade);
        //    TestCenter.CreateAndLogAirlineCompany(out LoginToken<AirlineCompany> airlineToken, out LoggedInAirlineFacade airlineFacade);
        //    TestCenter.CreateAndLogCustomer(out LoginToken<Customer> customerToken, out LoggedInCustomerFacade customerFacade);
        //    Flight flight = new Flight
        //    {
        //        AIRLINECOMPANY_ID = airlineFacade.GetAirlineByName(airlineToken, "Me109").ID,
        //        ORIGIN_COUNTRY_CODE = airlineFacade.GetCountryByName(airlineToken, "Germany").ID,
        //        DESTINATION_COUNTRY_CODE = airlineFacade.GetCountryByName(airlineToken, "Germany").ID,
        //        DEPARTURE_TIME = new DateTime(2020, 10, 10, 10, 00, 00),
        //        LANDING_TIME = new DateTime(2020, 10, 10, 10, 00, 00),
        //        REMAINING_TICKETS = 250,
        //    };
        //    Assert.AreEqual(customerFacade.GetAllMyFlights(customerToken).Count, 0);
        //    airlineFacade.CreateFlight(airlineToken, flight);
        //    Assert.AreEqual(customerFacade.GetAllMyFlights(customerToken).Count, 1);
        //}
        ////********************************************************************************
    }
}

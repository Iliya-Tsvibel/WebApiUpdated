﻿using FlightsManagementSystem;
using FlightsManagementSystem.DAO;
using FlightsManagementSystem.Facade;
using Fly_System_DB_Generator.StaticData;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using static Fly_System_DB_Generator.ApiModel;
using static Fly_System_DB_Generator.MainWindowViewModel;

namespace Fly_System_DB_Generator
{
    public class DBGeneratorClass
    {
        public static List<string> countryList;
        static public LoggedInAdministratorFacade adminFacade = new LoggedInAdministratorFacade();
        static public LoginToken<Administrator> adminToken = new LoginToken<Administrator> { User = new Administrator { USER_NAME = FlightCenterConfig.ADMIN_USER_NAME, PASSWORD = FlightCenterConfig.ADMIN_PASSWORD } };
        static public LoggedInAirlineFacade airlineFacade = new LoggedInAirlineFacade();
        //static public LoginToken<AirlineCompany> airlioneToken = new LoginToken<AirlineCompany> { User = new AirlineCompany { AIRLINE_NAME = FlightCenterConfigDB_Gen.AIRLINE_NAME, USER_NAME = FlightCenterConfigDB_Gen.AIRLINE_USER_NAME, PASSWORD = FlightCenterConfigDB_Gen.AIRLINE_PASSWORD, COUNTRY_CODE = adminFacade.GetCountryByName("Germany").ID } };
        static public LoginToken<Customer> defaultCustomerToken = new LoginToken<Customer> { User = new Customer { USER_NAME = FlightCenterConfigDB_Gen.CUSTOMER_USER_NAME, PASSWORD = FlightCenterConfigDB_Gen.CUSTOMER_PASSWORD } };
        static public LoggedInCustomerFacade customerFacade = new LoggedInCustomerFacade();
        static public LoginToken<Administrator> adminTokenDAO = new LoginToken<Administrator>();
        static public AnonymousUserFacade anonFacade = new AnonymousUserFacade();
        static public TicketDAOMSSQL ticketDAO = new TicketDAOMSSQL();
        static public FlightDAOMSSQL flightDAO = new FlightDAOMSSQL();
        static public CountryDAOMSSQL countryDAO = new CountryDAOMSSQL();
        static public AirlineDAOMSSQL airlineDAO = new AirlineDAOMSSQL();
        static public CustomerDAOMSSQL customerDAO = new CustomerDAOMSSQL();
        static public List<Customer> customers = new List<Customer>();
        private const string randomUsersApiURL = "https://randomuser.me/api";
        private HttpClient client = new HttpClient();

        public DBGeneratorClass()
        {
            client.BaseAddress = new Uri(randomUsersApiURL);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            //log4net.Config.XmlConfigurator.Configure();
        }

        Random random = new Random();

        public DateTime RandomDate()
        {
            DateTime randomDate = DateTime.Today.AddDays(random.Next(1, 365));
            return randomDate;
        }

        public void AddingCustomers(int num)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(randomUsersApiURL);
            client.DefaultRequestHeaders.Accept.Add(
            new MediaTypeWithQualityHeaderValue("application/json"));
            //int num = Int32.Parse(customerTB);
            for (int i = 0; i < num; i++)
            {
                HttpResponseMessage response = client.GetAsync("").Result;
                if (response.IsSuccessStatusCode)
                {
                    CustomerDAOMSSQL customerDAOMSSQL = new CustomerDAOMSSQL();

                    WebResult dataObjects = response.Content.ReadAsAsync<WebResult>().Result;
                    Customer c = new Customer();

                    c.ADDRESS = dataObjects.results[0].location.city;
                    c.CREDIT_CARD_NUMBER = dataObjects.results[0].cell;
                    c.FIRST_NAME = dataObjects.results[0].name.first;
                    c.LAST_NAME = dataObjects.results[0].name.last;
                    c.PASSWORD = dataObjects.results[0].login.password;
                    c.USER_NAME = dataObjects.results[0].login.username;
                    c.PHONE_NO = dataObjects.results[0].phone;

                    customerDAOMSSQL.Add(c);
                    //c = customerDAOMSSQL.GetCustomerByUserName(c.UserName);
                    //_vm.Current += 1;
                    //_vm.Status = (_vm.Current / Total) * 100;
                    ////  ProgressBarWork();
                }
                else
                {
                    Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
                }
                // client.Dispose();

            }
        }
        public Customer GetMinimumCustomerID()
        {
            return customerDAO.GetMinID();
        }
        public long RandomCustomerID()
        {
            long randomCustomerID = random.Next(Convert.ToInt32(GetMinimumCustomerID().ID), (Convert.ToInt32(GetMinimumCustomerID().ID) + 5)/*Convert.ToInt32(customerDAO.CountCustomers()-1)*/);
            return randomCustomerID;
        }
        public Flight GetMinimumFlightID()
        {
            return flightDAO.GetMinFlightID();
        }
        public long RandomFlightID()
        {
            long randomFlightID = random.Next(Convert.ToInt32(GetMinimumFlightID().ID), (Convert.ToInt32(GetMinimumFlightID().ID) + 100));
            return randomFlightID;
        }
        public long RandomCountryID()
        {
            long countryStartID = countryDAO.GetByName(ListOfCountries.CountryNames[0]).ID;
            long randomCuntryID = random.Next(Convert.ToInt32(countryStartID), (Convert.ToInt32(countryStartID) + ListOfCountries.CountryNames.Length));
            return randomCuntryID;
        }

        public long RandomAirlineID()
        {
            long airlineStartID = airlineDAO.GetAirlineByName(ListOfAirlinesCompanies.AirlineNames[0]).ID;
            long randomAirlineID = random.Next(Convert.ToInt32(airlineStartID), (Convert.ToInt32(airlineStartID) + ListOfAirlinesCompanies.AirlineNames.Length));
            return randomAirlineID;
        }

        public void GenerateDB()
        {
            int num = 10;
            AddingCustomers(num);

            // Creating new country.
            Country country = null;
            country = new Country();
            for (int i = 0; i < ListOfCountries.CountryNames.Length; i++)
            {

                country = countryDAO.GetByName(ListOfCountries.CountryNames[i]);

                if (country == null)
                {

                    Country newCountry = new Country { COUNTRY_NAME = ListOfCountries.CountryNames[i] };
                    adminFacade.CreateNewCountry(adminToken, newCountry);
                }

            }

            // Creating new administrator.
            Administrator newAdmin = new Administrator { FIRST_NAME = "Iliya", LAST_NAME = "Tsvibel", USER_NAME = "Admin", PASSWORD = "1234" };
            adminFacade.CreateNewAdmin(adminToken, newAdmin);

            // Creating new airline.
            AirlineCompany airline = null;
            airline = new AirlineCompany();
            for (int i = 0; i < ListOfAirlinesCompanies.AirlineNames.Length; i++)
            {

                airline = airlineDAO.GetAirlineByName(ListOfAirlinesCompanies.AirlineNames[i]);

                if (airline == null)
                {
                    AirlineCompany newAirline = new AirlineCompany { AIRLINE_NAME = ListOfAirlinesCompanies.AirlineNames[i], USER_NAME = "UserName-" + ListOfAirlinesCompanies.AirlineNames[i], PASSWORD = random.Next(1000, 10000).ToString(), COUNTRY_CODE = RandomCountryID() };
                    adminFacade.CreateNewAirline(adminToken, newAirline);
                }

            }

            // Creating new flight.
            for (int i = 0; i < 1000; i++)
            {
                Flight flight = new Flight { AIRLINECOMPANY_ID = RandomAirlineID(), DEPARTURE_TIME = DateTime.Now.AddDays(random.Next(1, 365)), LANDING_TIME = DateTime.Now.AddDays(random.Next(1, 365)), ORIGIN_COUNTRY_CODE = RandomCountryID(), DESTINATION_COUNTRY_CODE = RandomCountryID(), REMAINING_TICKETS = random.Next(1, 500) };
                //airlineFacade.CreateFlight(airlioneToken, flight);
                flightDAO.Add(flight);
            }

            // Creating new ticket.
            for (int i = 0; i < 1000; i++)
            {
                Ticket tickets = new Ticket { FLIGHT_ID = RandomFlightID(), CUSTOMER_ID = RandomCustomerID() };
                //customerFacade.PurchaseTicket(defaultCustomerToken, tickets);
                ticketDAO.Add(tickets);
            }
            
            MessageBox.Show($"All data successfully added");
        }


        private void Edit_Click(object sender, RoutedEventArgs e)
        {

        }

        public void DeleteDB()
        {
            using (SqlConnection sqlConnection = new SqlConnection(FlightCenterConfigDB_Gen.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("CLEAR_DB", sqlConnection))
                {
                    cmd.Connection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                }

            }
            MessageBox.Show($"All data successfully deleted");
        }
    }
}

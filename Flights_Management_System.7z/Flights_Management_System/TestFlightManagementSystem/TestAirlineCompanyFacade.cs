﻿using System;
using System.Collections.Generic;
using FlightsManagementSystem;
using FlightsManagementSystem.Facade;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestFlightManagementSystem
{
    [TestClass]
    public class TestAirlineCompanyFacade
    {
        //[TestMethod]
        //public void GetAllAirlineTickets()
        //{

        //    TestCenter.CleanAllDataBase(out LoginToken<Administrator> adminToken, out LoggedInAdministratorFacade adminFacade);
        //    TestCenter.CreateAndLogAirlineCompany(out LoginToken<AirlineCompany> airlineToken, out LoggedInAirlineFacade airlineFacade);
        //    TestCenter.CreateAndLogCustomer(out LoginToken<Customer> customerToken, out LoggedInCustomerFacade customerFacade);
        //    Flight flight = new Flight { AIRLINECOMPANY_ID = airlineToken.User.ID, DEPARTURE_TIME = DateTime.Now, LANDING_TIME = DateTime.Now + TimeSpan.FromHours(1), ORIGIN_COUNTRY_CODE = TestCenter.defaultFacade.GetCountryByName("Germany").ID, DESTINATION_COUNTRY_CODE = TestCenter.defaultFacade.GetCountryByName("Germany").ID, REMAINING_TICKETS = 250 };
        //    airlineFacade.CreateFlight(airlineToken, flight);
        //    customerFacade.PurchaseTicket(customerToken, flight);
        //    IList<Ticket> tickets = airlineFacade.GetAllTicketsByAirline(airlineToken, );
        //    Assert.AreEqual(1, tickets.Count);

        //   // *****************************************************

        //    test = new TestCenter();
        //    Flight flight = new Flight(test.airlineToken.User.Id, test.airlineToken.User.CountryCode, test.airlineToken.User.CountryCode, new DateTime(2020, 10, 10, 10, 00, 00), new DateTime(2020, 10, 11, 10, 00, 00), 100);
        //    flight.Id = test.airlineFacade.CreateFlight(test.airlineToken, flight);
        //    Assert.AreEqual(test.airlineFacade.GetAllTicketsByFlight(test.airlineToken, flight.Id).Count, 0);
        //    test.customerFacade.PurchaseTicket(test.customerToken, flight);
        //    Assert.AreEqual(test.airlineFacade.GetAllTicketsByFlight(test.airlineToken, flight.Id).Count, 1);
        //    Flight flight1 = new Flight(test.airlineToken.User.Id, test.airlineToken.User.CountryCode, test.airlineToken.User.CountryCode, new DateTime(2020, 10, 10, 12, 00, 00), new DateTime(2020, 10, 11, 11, 00, 00), 300);
        //    flight1.Id = test.airlineFacade.CreateFlight(test.airlineToken, flight1);
        //    Assert.AreEqual(test.airlineFacade.GetAllTicketsByFlight(test.airlineToken, flight.Id).Count, 1);
        //}
        [TestMethod]
        public void GetAllFlightsByAirlineTest()
        {
            TestCenter.CleanAllDataBase(out LoginToken<Administrator> adminToken, out LoggedInAdministratorFacade adminFacade);
            TestCenter.CreatingAirlineCompanyAndToken(out LoginToken<AirlineCompany> airlineToken, out LoggedInAirlineFacade airlineFacade);
            Flight flight = new Flight
            {
                AIRLINECOMPANY_ID = airlineFacade.GetAirlineByName(airlineToken, FlightCenterConfig.AIRLINE_NAME).ID,
                ORIGIN_COUNTRY_CODE = airlineFacade.GetCountryByName(airlineToken, FlightCenterConfig.COUNTRY_NAME).ID,
                DESTINATION_COUNTRY_CODE = airlineFacade.GetCountryByName(airlineToken, FlightCenterConfig.COUNTRY_NAME).ID,
                DEPARTURE_TIME = new DateTime(2020, 10, 10, 10, 00, 00),
                LANDING_TIME = new DateTime(2020, 10, 10, 10, 00, 00),
                REMAINING_TICKETS = 250
            };
            Assert.AreEqual(airlineFacade.GetAllFlights().Count, 0);
            airlineFacade.CreateFlight(airlineToken, flight);
            Assert.AreEqual(airlineFacade.GetAllFlights().Count, 1);

        }
        [TestMethod]
        public void CancelAllAirlineFlightTest()
        {

            TestCenter.CleanAllDataBase(out LoginToken<Administrator> adminToken, out LoggedInAdministratorFacade adminFacade);
            TestCenter.CreatingAirlineCompanyAndToken(out LoginToken<AirlineCompany> airlineToken, out LoggedInAirlineFacade airlineFacade);
            Flight flight = new Flight
            {
                AIRLINECOMPANY_ID = airlineFacade.GetAirlineByName(airlineToken, FlightCenterConfig.AIRLINE_NAME).ID,
                ORIGIN_COUNTRY_CODE = airlineFacade.GetCountryByName(airlineToken, FlightCenterConfig.COUNTRY_NAME).ID,
                DESTINATION_COUNTRY_CODE = airlineFacade.GetCountryByName(airlineToken, FlightCenterConfig.COUNTRY_NAME).ID,
                DEPARTURE_TIME = new DateTime(2020, 10, 10, 10, 00, 00),
                LANDING_TIME = new DateTime(2020, 10, 10, 10, 00, 00),
                REMAINING_TICKETS = 250,

            };
            Assert.AreEqual(airlineFacade.GetAllFlights().Count, 0);
            airlineFacade.CreateFlight(airlineToken, flight);
            Assert.AreEqual(airlineFacade.GetAllFlights().Count, 1);
            IList<Flight> flights = airlineFacade.GetAllFlights();
            airlineFacade.CancelFlight(airlineToken, flights[0]);
            Assert.AreEqual(airlineFacade.GetAllFlights().Count, 0);
        }
        [TestMethod]
        public void UpdateFlightTest()
        {

            TestCenter.CleanAllDataBase(out LoginToken<Administrator> adminToken, out LoggedInAdministratorFacade adminFacade);
            TestCenter.CreatingAirlineCompanyAndToken(out LoginToken<AirlineCompany> airlineToken, out LoggedInAirlineFacade airlineFacade);
            Flight updateFlight = new Flight
            {
                AIRLINECOMPANY_ID = airlineFacade.GetAirlineByName(airlineToken, FlightCenterConfig.AIRLINE_NAME).ID,
                ORIGIN_COUNTRY_CODE = airlineFacade.GetCountryByName(airlineToken, FlightCenterConfig.COUNTRY_NAME).ID,
                DESTINATION_COUNTRY_CODE = airlineFacade.GetCountryByName(airlineToken, FlightCenterConfig.COUNTRY_NAME).ID,
                DEPARTURE_TIME = new DateTime(2020, 10, 10, 10, 00, 00),
                LANDING_TIME = new DateTime(2020, 10, 10, 10, 00, 00),
                REMAINING_TICKETS = 250,

            };
            Assert.AreEqual(airlineFacade.GetAllFlights().Count, 0);
            airlineFacade.CreateFlight(airlineToken, updateFlight);
            Assert.AreEqual(airlineFacade.GetAllFlights().Count, 1);
            updateFlight = airlineFacade.GetFlightById(airlineToken, updateFlight.ID);
            updateFlight.REMAINING_TICKETS = 200;
            airlineFacade.UpdateFlight(airlineToken, updateFlight);
            Assert.AreEqual(updateFlight.REMAINING_TICKETS, 200);

        }

        [TestMethod]
        public void ChangePasswordAirlinePasswordTest()
        {
            TestCenter.CleanAllDataBase(out LoginToken<Administrator> adminToken, out LoggedInAdministratorFacade adminFacade);
            TestCenter.CreatingAirlineCompanyAndToken(out LoginToken<AirlineCompany> airlineToken, out LoggedInAirlineFacade airlineFacade);
            airlineFacade.ChangeMyPassword(airlineToken, "1234", "12345");
            Assert.AreEqual(airlineToken.User.PASSWORD, "12345".ToUpper());
        }

        [TestMethod]
        public void UpdateAirlineDetailsTest()
        {

            TestCenter.CleanAllDataBase(out LoginToken<Administrator> adminToken, out LoggedInAdministratorFacade adminFacade);
            TestCenter.CreatingAirlineCompanyAndToken(out LoginToken<AirlineCompany> airlineToken, out LoggedInAirlineFacade airlineFacade);
            Assert.AreEqual(airlineFacade.GetAllAirlineCompanies().Count, 1);
            AirlineCompany updateAirline = new AirlineCompany
            {
                AIRLINE_NAME = "Lufthansa"
            };
            //airlineToken.User.AIRLINE_NAME = "Lufthansa";
            airlineFacade.MofidyAirlineDetails(airlineToken, /*airlineToken.User*/updateAirline);
            Assert.AreEqual(adminFacade.GetAirlineByName(adminToken, airlineToken.User.AIRLINE_NAME).AIRLINE_NAME, airlineToken.User.AIRLINE_NAME);
        }
    }
}